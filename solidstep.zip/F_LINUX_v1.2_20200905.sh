#!/bin/sh

LANG=C
export LANG
BUILD_VER=1.0
LAST_UPDATE=2020.01
alias ls=ls
_HOST_NAME=`hostname`
DATE=`date '+%F'`
CREATE_FILE=`hostname`"_before_ini_".txt

echo "=============================================================================="
echo " 		Copyright (c) 2020 InnoSecuriy Co. Ltd. All rights Reserved. "
echo "		Linux Vulnerability Scanner Version $BUILD_VER ($LAST_UPDATE)"
echo "=============================================================================="
echo " "
echo " "
echo "========= Starting Linux Vulnerability Scanner $BUILD_VER ========="
echo " "
echo " "
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo " 		Copyright (c) 2020 InnoSecuriy Co. Ltd. All rights Reserved. "				  >> $CREATE_FILE 2>&1
echo "		Linux Vulnerability Scanner Version $BUILD_VER ($LAST_UPDATE)"			  >> $CREATE_FILE 2>&1
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo "========= Starting Linux Vulnerability Scanner $BUILD_VER ========="			  >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo "Check Time : `date`"                                                            >> $CREATE_FILE 2>&1
echo "Hostname   : `hostname`"														  >> $CREATE_FILE 2>&1
echo "Kernal     : `uname -a`"														  >> $CREATE_FILE 2>&1
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo "[Apache 활성화 여부]" >> $CREATE_FILE 2>&1
#Apache 환경설정 관련
web='default'
path='none'
if [ `ps -ef | egrep -i "httpd|apache2" | grep -v "grep" | grep -v "ns-httpd" | grep -i -v "IBM" | grep -i -v "ihs" | grep -i -v "ohs" | wc -l` -ge 1 ]; then 	
	if [ `ps -ef | egrep -i "httpd|apache2" | grep -v "ns-httpd" | grep -v "grep" | grep -i -v "IBM" | grep -i -v "ihs" | grep -i -v "ohs" | awk -F' ' '{print $8}' | grep "/" | grep -v "httpd.conf" | uniq | wc -l` -ge 1 ]; then
		web='httpd'
		ps -ef | egrep -i "httpd|apache2" | grep -v "ns-httpd" | grep -v "grep" | awk -F' ' '{print $8}' | grep "/" | grep -v "httpd.conf" | uniq >> webdir.txt
		webdir=`cat -n webdir.txt | grep 1 | awk -F' ' '{print $2}'`
		
		($webdir -V >pathinfo.txt ) 2>error.txt
		
		if [ -s pathinfo.txt ]; then
			apache=`$webdir -V | grep -i "httpd_root" | awk -F'"' '{print $2}'`
			conf=`$webdir -V | grep -i "server_config_file" | awk -F'"' '{print $2}'`
			if [ ! -f $conf ];then
				path='ok'
				conf="$apache/$conf"
				docroot=`cat "$conf" |grep DocumentRoot |grep -v '\#'|awk -F'"' '{print $2}'`
				svrroot=`cat "$conf" |grep ServerRoot |grep -v '\#'|awk -F'"' '{print $2}'`
				svrroot=${svrroot:-"$apache"}
			fi
			#docroot=`cat $conf | grep -i documentroot  | grep -v '#' | awk -F'"' '{print $2}'`
		fi
		#docroot=`cat $conf | grep -i documentroot  | grep -v '#' | awk -F'"' '{print $2}'`
		rm -rf webdir.txt
		$webdir -v >> $CREATE_FILE 2>&1
	elif [ `ps -ef | egrep -i "httpd|apache2" | grep -v "ns-httpd" | grep -v "grep" | grep -i -v "IBM" | grep -i -v "ihs" | grep -i -v "ohs" | awk -F' ' '{print $9}' | grep "/" | grep -v "httpd.conf" | uniq | wc -l` -ge 1 ]; then
		web='httpd'
		ps -ef | egrep -i "httpd|apache2" | grep -v "ns-httpd" | grep -v "grep" | grep -i -v "IBM" | grep -i -v "ohs" | awk -F' ' '{print $9}' | grep "/" | grep -v "httpd.conf" | uniq >> webdir.txt
		webdir=`cat -n webdir.txt | grep 1 | awk -F' ' '{print $2}'`
		
		($webdir -V >pathinfo.txt ) 2>error.txt
		
		if [ -s pathinfo.txt ]; then
			apache=`$webdir -V | grep -i "httpd_root" | awk -F'"' '{print $2}'`
			conf=`$webdir -V | grep -i "server_config_file" | awk -F'"' '{print $2}'`
			echo $conf
			if [ ! -f $conf ];then
				path='ok'
				conf="$apache/$conf"
				echo $conf
				docroot=`cat "$conf" |grep DocumentRoot |grep -v '\#'|awk -F'"' '{print $2}'`
				svrroot=`cat "$conf" |grep ServerRoot |grep -v '\#'|awk -F'"' '{print $2}'`
				svrroot=${svrroot:-"$apache"}
			fi
			#docroot=`cat $conf | grep -i documentroot  | grep -v '#' | awk -F'"' '{print $2}'`
		fi
		#docroot=`cat $conf | grep -i documentroot | grep -v '#' | awk -F'"' '{print $2}'`
		rm -rf webdir.txt
		$webdir -v >> $CREATE_FILE 2>&1
	else
		echo "Apache 환경 변수 세팅 미흡. 수동진단 필요" >> $CREATE_FILE 2>&1
	fi	
else
	echo "Apache 서비스 비활성화" >> $CREATE_FILE 2>&1
fi
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo " "																			  >> $CREATE_FILE 2>&1



U_01() {
  echo -n "SRV-001. SNMP 서비스 Community 스트링 설정 오류 >>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-001. SNMP 서비스 Community 스트링 설정 오류" >> $CREATE_FILE 2>&1
  echo ":: SNMP Community 이름이 public, private 가 아닌 경우 양호"  >> $CREATE_FILE 2>&1
  echo "추측하기 어려운 값으로 설정되어 있는 경우 양호"  >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1


  echo "① SNMP 포트확인 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `cat /etc/services | awk -F" " '$1=="snmp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "udp" | wc -l` -ge 1 ]
	then 
		cat /etc/services | awk -F" " '$1=="snmp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "udp" >> $CREATE_FILE 2>&1
	else
		echo "(1)/etc/service 파일 : 포트설정 X" >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  
  echo "② SNMP 서비스 포트 활성화 여부 " >> $CREATE_FILE 2>&1
    if [ `cat /etc/services | awk -F" " '$1=="snmp" {print $1 "   " $2}' | grep "udp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}' | wc -l` -ge 1 ]
    then
	    snmpport=`cat /etc/services | awk -F" " '$1=="snmp" {print $1 "   " $2}' | grep "udp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}'`;

	    if [ `netstat -nat | grep ":$snmpport " | grep -i "^udp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$snmpport " | grep -i "^udp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "SNMP 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
			  echo "BAD" > u01.txt
			  echo "SNMPENABLE" > snmpenable.txt
		   else
		      echo "SNMP 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
              echo "GOOD" > u01.txt		   
			  echo "SNMPDISABLE" > snmpenable.txt
		fi	  
    else
	    netstat -nat | grep ":161 " | grep -i "^udp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
	    echo "SNMP 서비스가 비활성화되어 있습니다.">> $CREATE_FILE 2>&1
		echo "GOOD" > u01.txt
		echo "SNMPDISABLE" > snmpenable.txt
  fi

        echo " " >> $CREATE_FILE 2>&1

        echo "② 설정파일 CommunityString 현황 " >> $CREATE_FILE 2>&1
        echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

        SPCONF_DIR="/etc/snmpd.conf /etc/snmpdv3.conf /etc/snmp/snmpd.conf /etc/snmp/conf/snmpd.conf /etc/sma/snmp/snmpd.conf"

        for file in $SPCONF_DIR
        do
        if [ -f $file ]
        then
                echo "■ "$file"파일 내 CommunityString 설정" >> $CREATE_FILE 2>&1
                echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
                echo " " >> $CREATE_FILE 2>&1
                echo "1)Snmp 권한 설정" >> $CREATE_FILE 2>&1
                cat $file | grep "^access" | grep -v "^#" >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
                echo "2)Snmp 그룹 설정" >> $CREATE_FILE 2>&1
                cat $file | grep "^group" | grep -v "^#" >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
                echo "3)Snmp 유저 설정" >> $CREATE_FILE 2>&1
                cat $file | grep "^com2sec" | grep -v "^#" >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
        fi
        done

        if [ `cat /etc/snmp/snmpd.conf | grep -i "access" | grep -v "^#" | awk '{print $7}' | grep -v none | wc -l` -eq 0 ]
        then
                echo "SNMP community 설정이 없습니다." >> $CREATE_FILE 2>&1
                echo "GOOD" >> u01.txt
        else
                groups=`cat /etc/snmp/snmpd.conf | grep -i "^access" | grep -v "^#" | awk '{if ($7!="none") print $2}'`
                echo "4)Snmp Community 설정 Community 정보 " >> $CREATE_FILE 2>&1
                echo " " >> $CREATE_FILE 2>&1
                for group in $groups
                do
                        users=`cat /etc/snmp/snmpd.conf | grep -i "^group" | grep -v "^#" | grep -w $group | awk '{print $4}' | uniq`
                        for user in $users
                        do
                                cat /etc/snmp/snmpd.conf | grep -i "^com2sec" | grep -v "^#" | grep -w $user >> $CREATE_FILE 2>&1
                                if [ `cat /etc/snmp/snmpd.conf | grep -i "^com2sec" | grep -v "^#" | grep -w $user | egrep "public|private" | wc -l` -eq 0 ]
                                        then
                                                echo "MANUAL" >> u01.txt
                                        else
                                                echo "BAD" >> u01.txt
                                fi
                        done
                done
        fi

        if [ `cat u01.txt | grep "BAD" | wc -l` -ge 2 ]; then
                echo " " >> $CREATE_FILE 2>&1
                echo "★ SRV-001. 결과 : 취약" >> $CREATE_FILE 2>&1
        elif [ `cat u01.txt | grep "MANUAL" | wc -l` -ge 1 ]; then
                echo " " >> $CREATE_FILE 2>&1
                echo "★ SRV-001. 결과 : 수동진단" >> $CREATE_FILE 2>&1
        else
                echo " " >> $CREATE_FILE 2>&1
                echo "★ SRV-001. 결과 : 양호" >> $CREATE_FILE 2>&1
        fi

  rm -rf u01.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_02() {
  echo -n "SRV-004. 불필요한 SMTP 서비스 실행 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"

  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-004. 불필요한 SMTP 서비스 실행 여부" >> $CREATE_FILE 2>&1
  echo ":: 불필요한 Sendmail을 사용하는 경우 취약 (인터뷰 필요)"        >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1 
  echo " " >> $CREATE_FILE 2>&1
	
  echo "① SMTP 포트확인 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `cat /etc/services | awk -F" " '$1=="smtp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" | wc -l` -ge 1 ]
	then 
		cat /etc/services | awk -F" " '$1=="smtp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" >> $CREATE_FILE 2>&1
	else
		echo "(1)/etc/service 파일 : 포트설정 X" >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  
  echo "② SMTP 서비스 포트 활성화 여부 " >> $CREATE_FILE 2>&1
    if [ `cat /etc/services | awk -F" " '$1=="smtp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}' | wc -l` -ge 1 ]
    then
	    smtpport=`cat /etc/services | awk -F" " '$1=="smtp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}'`;

	    if [ `netstat -nat | grep ":$smtpport " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$smtpport " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
			  echo " " >> $CREATE_FILE 2>&1
		      echo "SMTP 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
			  echo "BAD" > u03.txt
			  echo "SMTPENABLE" > smtpenable.txt
		   else
		      echo "SMTP 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
              echo "GOOD" > u03.txt		   
			  echo "SMTPDISABLE" > smtpenable.txt
		fi	  
    else
	    netstat -nat | grep ":25 " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
	    echo "SMTP 서비스가 비활성화되어 있습니다.">> $CREATE_FILE 2>&1
		echo "GOOD" > u03.txt
		echo "SMTPDISABLE" > smtpenable.txt
  fi
   echo " " >> $CREATE_FILE 2>&1
 
    if [ `cat u03.txt | grep -i "BAD" | wc -l` -ge 1 ]
	   then
		  echo "★ SRV-004. 결과 : 취약" >> $CREATE_FILE 2>&1
	   else
	      echo "★ SRV-004. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi

    rm -rf u03.txt
	
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_03() {
  echo -n "SRV-005. SMTP 서비스 expn/vrfy 명령어 실행 가능 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-005. SMTP 서비스 expn/vrfy 명령어 실행 가능 여부 " >> $CREATE_FILE 2>&1
  echo ":: SMTP 서비스 미사용 또는, noexpn, novrfy 옵션이 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  ls -al /etc/rc*.d/* | grep -i sendmail | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  echo "② /etc/mail/sendmail.cf 파일의 옵션 확인" >> $CREATE_FILE 2>&1
  cat /etc/mail/sendmail.cf | grep -i "O PrivacyOptions" | grep -v "^#" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
    then
      echo "★ SRV-005. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
	  if [ -f cat/etc/mail/sendmail.cf ] 
		then
			if [ `cat /etc/mail/sendmail.cf | grep -i "O PrivacyOptions" | grep -i "noexpn" | grep -i "novrfy" | grep -v "^#" | wc -l ` -eq 1 ]
			then
				echo "★ SRV-005. 결과 : 양호" >> $CREATE_FILE 2>&1
			else
				echo "★ SRV-005. 결과 : 취약" >> $CREATE_FILE 2>&1
			fi
		else
			echo "/etc/mail/sendmail.cf 파일이 존재하지않습니다" >> $CREATE_FILE 2>&1
			echo "★ SRV-005. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi	
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_04() {
	echo -n "SRV-006. Sendmail Log Level 미설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"

	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-006. Sendmail Log Level 미설정" >> $CREATE_FILE 2>&1
	echo ":: LogLevel=[값] 설정되어 있을 경우 양호, 아무런 설정값이 없을 경우 취약"        >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1 
	echo " " >> $CREATE_FILE 2>&1


  echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi
  
    echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/mail/sendmail.cf ]; then
	cat /etc/mail/sendmail.cf | grep -v '^#' | egrep "LogLevel=[0-9]" | awk -F= '{print $2}' > loglv.txt
	fi
	
	echo "② /etc/mail/sendmail.cf 파일의 LogLevel 확인" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/mail/sendmail.cf ]; then
		if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | egrep "LogLevel=[0-9]" | wc -l` -gt 0 ]
		then
			cat /etc/mail/sendmail.cf | egrep -i "LogLevel" | grep -v "^#" >> $CREATE_FILE 2>&1
		else
			echo "/etc/mail/sendmail.cf 파일에 설정값이 없습니다." >> $CREATE_FILE 2>&1
		fi
	else
		echo "/etc/mail/sendmail.cf 파일이 없습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
	  then
	    echo "★ SRV-006. 결과 : 양호" >> $CREATE_FILE 2>&1
	  else
		if [ -f /etc/mail/sendmail.cf -a `cat loglv.txt | wc -l` -eq 1 ]; then
			if [ `cat loglv.txt` -ge 0 -a `cat loglv.txt` -le 15 ]
			then  
				echo "★ SRV-006. 결과 : 양호" >> $CREATE_FILE 2>&1
			else
				echo "★ SRV-006. 결과 : 취약" >> $CREATE_FILE 2>&1
			fi
		else
			echo "★ SRV-006. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi
	
	rm -rf loglv.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_05() {
  echo -n "SRV-007. 취약한 버전의 Sendmail 사용 여부  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-007. 취약한 버전의 Sendmail 사용 여부 " >> $CREATE_FILE 2>&1
  echo ":: Sendmail 버전이 8.15.2 이상인 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  ls -al /etc/rc*.d/* | grep -i sendmail | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  echo "② sendmail 버전확인" >> $CREATE_FILE 2>&1
  if [ -f /etc/mail/sendmail.cf ]
    then
      grep -v '^ *#' /etc/mail/sendmail.cf | grep DZ >> $CREATE_FILE 2>&1
    else
      echo "/etc/mail/sendmail.cf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
    then
      echo "★ SRV-007. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/mail/sendmail.cf ]
        then
          if [ `grep -v '^ *#' /etc/mail/sendmail.cf | egrep "DZ8.15.2" | wc -l ` -eq 1 ]
            then
              echo "★ SRV-007. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-007. 결과 : 수동진단" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-007. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_06() {
	echo -n "SRV-008. Sendmail 서비스 거부 방지 기능 미설정	>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-008. Sendmail 서비스 거부 방지 기능 미설정" >> $CREATE_FILE 2>&1
	echo ":: 영문·숫자·특수문자가 혼합된 9자리 이상의 패스워드가 설정된 경우 양호"        >> $CREATE_FILE 2>&1
	echo "MaxDaemonChildren : 메일서버가 만들 수 있는 자식서버 수">> $CREATE_FILE 2>&1
	echo "ConnectionRateThrottle : 초당 수용 가능한 클라이어느 수">> $CREATE_FILE 2>&1
	echo "MinFreeBlocks : 메일 수용을 위한 최소 free Block">> $CREATE_FILE 2>&1
	echo "MaxHeaderLength : 최대 수용 가능 헤더 길이">> $CREATE_FILE 2>&1
	echo "MaxMessageSize : 첨부파일을 포함한 메일 메시지 최대크기 제한 설정 부분(byte 단위)">> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1 
	echo " " >> $CREATE_FILE 2>&1

	echo "" > SRV-008.txt 2>&1
	
  echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi
	echo " " >> $CREATE_FILE 2>&1
	
	echo "② /etc/mail/sendmail.cf 파일의 설정값 확인" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/mail/sendmail.cf ]
	then
	cat /etc/mail/sendmail.cf | egrep -i "MaxDaemonChildren|ConnectionRateThrottle|MinFreeBlocks|MaxHeadersLength|MaxMessageSize" | grep -v "^#" >> $CREATE_FILE 2>&1
	else
	echo " /etc/mail/sendmail.cf 파일이 존재하지 않음 " >> $CREATE_FILE 2>&1
	fi
	echo " " >> $CREATE_FILE 2>&1
	
	
	# 1번 MaxDaemonChildren
	if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | grep -i "MaxDaemonChildren" | wc -l` -eq 0 ]
	  then
	    echo "MaxDaemonChildren 설정값이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	    echo "BAD" >> SRV-008.txt
	  else
	  MaxDa=`cat /etc/mail/sendmail.cf |grep -v '^#' | grep -i "MaxDaemonChildren=" | awk -F= '{print $2}'`
		if [ "$MaxDa -lt 0 -o $Maxda -gt 12" ]
		  then
			echo "GOOD" >> SRV-008.txt 
		  else
			echo "MaxDaemonChildren 설정값이 올바르지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi
	
	# 2번 ConnectionRateThrottle
	if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | grep -i "ConnectionRateThrottle" | wc -l` -eq 0 ]
	  then
	    echo "ConnectionRateThrottle 설정값이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	    echo "BAD" >> SRV-008.txt
	  else
	  Connect=`cat /etc/mail/sendmail.cf |grep -v '^#' | grep -i "ConnectionRateThrottle=" | awk -F= '{print $2}'`
		if [ "$Connect -lt 0 -o $Connect -gt 12" ]
		  then
			echo "GOOD" >> SRV-008.txt 
		  else
			echo "ConnectionRateThrottle 설정값이 올바르지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi
	
	# 3번 MinFreeBlocks
	if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | grep -i "MinFreeBlocks" | wc -l` -eq 0 ]
	  then
	    echo "MinFreeBlocks 설정값이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	    echo "BAD" >> SRV-008.txt
	  else
	  MinFr=`cat /etc/mail/sendmail.cf |grep -v '^#' | grep -i "MinFreeBlocks=" | awk -F= '{print $2}'`
		if [ "$MinFr -lt 0 -o $MinFr -gt 100" ]
		  then
			echo "GOOD" >> SRV-008.txt 
		  else
			echo "MinFreeBlocks 설정값이 올바르지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi
	
	# 4번 MaxHeadersLength
	if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | grep -i "MaxHeadersLength" | wc -l` -eq 0 ]
	  then
	    echo "MaxHeadersLength 설정값이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	    echo "BAD" >> SRV-008.txt
	  else
	  MaxHe=`cat /etc/mail/sendmail.cf |grep -v '^#' | grep -i "MaxHeadersLength=" | awk -F= '{print $2}'`
		if [ "$MaxHe -lt 0 -o $MaxHe -gt 50000" ]
		  then
			echo "GOOD" >> SRV-008.txt 
		  else
			echo "MaxHeadersLength 설정값이 올바르지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi
	
	# 5번 MaxMessageSize
	if [ `cat /etc/mail/sendmail.cf | grep -v '^#' | grep -i "MaxMessageSize" | wc -l` -eq 0 ]
	  then
	    echo "MaxMessageSize 설정값이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	    echo "BAD" >> SRV-008.txt
	  else
	  MaxMe=`cat /etc/mail/sendmail.cf |grep -v '^#' | grep -i "MaxMessageSize=" | awk -F= '{print $2}'`
		if [ "$MaxMe -lt 0 -o $MaxMe -gt 2000000" ]
		  then
			echo "GOOD" >> SRV-008.txt 
		  else
			echo "MaxMessageSize 설정값이 올바르지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi
	echo " " >> $CREATE_FILE 2>&1
	if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
	  then
	    echo "★ SRV-008. 결과 : 양호" >> $CREATE_FILE 2>&1
	  else
		if [ `cat SRV-008.txt | grep "GOOD" | wc -l` -ge 5 ]
		  then
		    echo "★ SRV-008. 결과 : 양호" >> $CREATE_FILE 2>&1	
		  else
			echo "★ SRV-008. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi
	
	rm -rf SRV-008.txt
	
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_07() {
  echo -n "SRV-009. 스팸 메일 릴레이 제한  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-009. 스팸 메일 릴레이 제한 " >> $CREATE_FILE 2>&1
  echo ":: SMTP 서비스를 사용하지 않거나 릴레이 제한이 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

 echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi
	echo " " >> $CREATE_FILE 2>&1

  ls -al /etc/rc*.d/* | grep -i sendmail | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  echo "② /etc/mail/sendmail.cf 파일의 옵션 확인" >> $CREATE_FILE 2>&1

  if [ -f /etc/mail/sendmail.cf ]
    then
      cat /etc/mail/sendmail.cf | grep "R$\*" | grep "Relaying denied" >> $CREATE_FILE 2>&1
    else
      echo "/etc/mail/sendmail.cf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
    then
      echo "★ SRV-009. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/mail/sendmail.cf ]
        then
          if [ `cat /etc/mail/sendmail.cf | grep -v "^#" | grep "R$\*" | grep -i "Relaying denied" | wc -l ` -gt 0 ]
            then
              echo "★ SRV-009. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-009. 결과 : 취약" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-009. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
  fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_08() {
  echo -n "SRV-010. 일반사용자의 Sendmail 실행 방지  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-010. 일반사용자의 Sendmail 실행 방지 " >> $CREATE_FILE 2>&1
  echo ":: SMTP 서비스 미사용 또는, 일반 사용자의 Sendmail 실행 방지가 설정 된 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

 echo "① Sendmail 서비스 포트 활성화 여부" >> $CREATE_FILE 2>&1
  
  if [ `cat smtpenable.txt | grep -i "SMTPENABLE" | wc -l` -eq 1 ]
	then
		echo "Sendmail 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "Sendmail 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi
	echo " " >> $CREATE_FILE 2>&1

  ls -al /etc/rc*.d/* | grep -i sendmail | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  echo "② /etc/mail/sendmail.cf 파일의 옵션 확인" >> $CREATE_FILE 2>&1
  if [ -f /etc/mail/sendmail.cf ]
    then
      grep -v '^ *#' /etc/mail/sendmail.cf | grep PrivacyOptions >> $CREATE_FILE 2>&1
    else
      echo "/etc/mail/sendmail.cf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat smtpenable.txt | grep -i "SMTPDISABLE" | wc -l` -ge 1 ]
    then
      echo "★ SRV-010. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/mail/sendmail.cf ]
        then
          if [ `cat /etc/mail/sendmail.cf | grep -i "O PrivacyOptions" | grep -i "restrictqrun" | grep -v "^#" |wc -l ` -eq 1 ]
            then
              echo "★ SRV-010. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-010. 결과 : 취약" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-010. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
  fi
  
  rm -rf smtpenable.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_09() {
  echo -n "SRV-011. ftpusers 파일 내 시스템 계정 존재 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-011. ftpusers 파일 내 시스템 계정 존재 여부 " >> $CREATE_FILE 2>&1
  echo ":: FTP 서비스가 비활성화 되어 있거나, 활성화 시 FTP 인가된 사용자만 사용하는 계정이 별도로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "root 제외한 다른 계정들의 적절성 여부를 점검" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  find /etc -name "proftpd.conf" > proftpd.txt
  find /etc -name "vsftpd.conf" > vsftpd.txt
  profile=`cat proftpd.txt`
  vsfile=`cat vsftpd.txt`
  
  echo "①-① /etc/services 파일에서 포트 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `cat /etc/services | awk -F" " '$1=="ftp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" | wc -l` -gt 0 ]
    then
	    cat /etc/services | awk -F" " '$1=="ftp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" >> $CREATE_FILE 2>&1
    else
	    echo "(1)/etc/service파일: 포트 설정 X (Default 21번 포트)" >> $CREATE_FILE 2>&1
  fi

  if [ -s vsftpd.txt ]
    then
	    if [ `cat $vsfile | grep "listen_port" | grep -v "^#" | awk '{print "(3)VsFTP 포트: " $1 "  " $2}' | wc -l` -gt 0 ]
	      then
		      cat $vsfile | grep "listen_port" | grep -v "^#" | awk '{print "(3)VsFTP 포트: " $1 "  " $2}' >> $CREATE_FILE 2>&1
	      else
		      echo "(2)VsFTP 포트: 포트 설정 X (Default 21번 포트 사용중)" >> $CREATE_FILE 2>&1
	    fi
    else
	    echo "(2)VsFTP 포트: VsFTP가 설치되어 있지 않습니다." >> $CREATE_FILE 2>&1
  fi


  if [ -s proftpd.txt ]
    then
	    if [ `cat $profile | grep "Port" | grep -v "^#" | awk '{print "(2)ProFTP 포트: " $1 "  " $2}' | wc -l` -gt 0 ]
	      then
		      cat $profile | grep "Port" | grep -v "^#" | awk '{print "(2)ProFTP 포트: " $1 "  " $2}' >> $CREATE_FILE 2>&1
	      else
		      echo "(3)ProFTP 포트: 포트 설정 X (/etc/service 파일에 설정된 포트 사용중)" >> $CREATE_FILE 2>&1
	    fi
    else
	    echo "(3)ProFTP 포트: ProFTP가 설치되어 있지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1  
  
  echo "①-② 서비스 포트 활성화 여부 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
    ################# /etc/services 파일에서 포트 확인 #################

  if [ `cat /etc/services | awk -F" " '$1=="ftp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}' | wc -l` -gt 0 ]
    then
	    port=`cat /etc/services | awk -F" " '$1=="ftp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}'`;
	    
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable" > ftpenable.txt
	    fi
    else
	    netstat -nat | grep ":21 " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
	    echo "ftp disable" > ftpenable.txt
  fi

  ################# vsftpd 에서 포트 확인 ############################

  if [ -s vsftpd.txt ]
    then
	    if [ `cat $vsfile | grep "listen_port" | grep -v "^#" | awk -F"=" '{print $2}' | wc -l` -eq 0 ]
	      then
		      port=21
	      else
		      port=`cat $vsfile | grep "listen_port" | grep -v "^#" | awk -F"=" '{print $2}'`
	    fi
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable" >> ftpenable.txt
	    fi
	  else
	    echo "ftp disable" >> ftpenable.txt
  fi

  ################# proftpd 에서 포트 확인 ###########################

  if [ -s proftpd.txt ]
    then
	    port=`cat $profile | grep "Port" | grep -v "^#" | awk '{print $2}'`
	    
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable"  >> ftpenable.txt
		    else
		      echo "ftp disable" >> ftpenable.txt
	    fi
	  else
	    echo "ftp disable" >> ftpenable.txt
  fi
  
	if [ `cat ftpenable.txt | grep -i "ftp disable" | wc -l` -eq 3 ]
		then
			echo "서비스 포트가 활성화 되어 있지 않습니다." >> $CREATE_FILE 2>&1
	fi 
  
  echo $ftpenable >> $CREATE_FILE
  
  if [ `cat ftpenable.txt | grep "enable" | wc -l` -gt 0 ]
    then
	  echo "enable" >> ftpact.txt
    else
      echo "disable" >> ftpact.txt
  fi
  
   echo "①-③ FTP 서비스 활성화 여부 확인" >> $CREATE_FILE 2>&1
   echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  if [ -f ftpact.txt ]
   then
     if [ `cat ftpact.txt | grep "enable" | wc -l` -eq 1 ]
	  then 
	    echo "FTP 서비스가 활성화 상태입니다." >> $CREATE_FILE 2>&1
	  else
	    echo "FTP 서비스가 비활성화 상태입니다." >> $CREATE_FILE 2>&1
	 fi
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  echo "② FTP 서비스 설정 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  if [ -f ftpenable.txt ] 
   then 
     if [ `cat ftpenable.txt | grep "enable" | wc -l` -gt 0 ]
      then
       if [ -f /etc/ftpd/ftpusers ]
        then
          echo "☞ /etc/ftpd/ftpusers 파일 설정 값" >> $CREATE_FILE 2>&1
          cat /etc/ftpd/ftpusers | grep -v 'root' | grep -v '^#' >> $CREATE_FILE 2>&1
		  echo " " >> $CREATE_FILE 2>&1
        else
          echo "☞ /etc/ftpd/ftpusers  파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
		  echo " " >> $CREATE_FILE 2>&1
      fi
	  fi	

      echo " " >> $CREATE_FILE 2>&1
  
      if [ -f /etc/ftpusers ]
        then
          echo "☞ /etc/ftpuser 파일 설정 값" >> $CREATE_FILE 2>&1
          cat /etc/ftpusers | grep -v 'root' | grep -v '^#' >> $CREATE_FILE 2>&1
		  echo " " >> $CREATE_FILE 2>&1
        else
		  if [ -f /etc/vsftpd/ftpusers ]
			then
				echo "☞ /etc/vsftpd/ftpuser 파일 설정 값" >> $CREATE_FILE 2>&1
				cat /etc/vsftpd/ftpusers | grep -v 'root' | grep -v '^#' >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
			else
				echo "☞ /etc/ftpusers 및 /etc/vsftpd/ftpusers 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
		fi
      fi
	
      if [ -f /etc/vsftpd/user_list ]
        then
          echo "☞ /etc/vsftpd/user_list 파일 설정 값" >> $CREATE_FILE 2>&1
		  cat /etc/vsftpd/user_list | grep -v 'root' | grep -v '^#' >> $CREATE_FILE 2>&1
		  echo " " >> $CREATE_FILE 2>&1
        else
          echo "/etc/vsftpd/user_list 파일이 존재하지 않습니다. " >> $CREATE_FILE 2>&1
		  echo " " >> $CREATE_FILE 2>&1
      fi
  
  else
    echo "☞ ftp 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " > ftp.txt

  FILES="/etc/ftpusers /etc/ftpd/ftpusers /etc/vsftpd/ftpusers /etc/vsftpd/user_list"

  for check_file in $FILES
	do
	  if [ -f $check_file ]
	    then 
		  cat $check_file 2>/dev/null | grep -v "^#" >> ftp.txt
	  fi
	done

  echo " " >> $CREATE_FILE 2>&1

  if [ -f ftpenable.txt ]
   then 
    if [ `cat ftpenable.txt | grep "enable" | wc -l` -gt 0 ]
     then
       if [ `cat ftp.txt | grep -v "root" | grep -v grep | wc -l` -eq 0 ]
        then
          echo "★ SRV-011. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ `cat ftp.txt | grep root | grep -v grep | wc -l` -eq 0 ]
		then
		  echo "★ SRV-011. 결과 : 취약" >> $CREATE_FILE 2>&1
        else
          echo "★ SRV-011. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
    else
      echo "★ SRV-011. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi
fi
  rm -rf ftpenable.txt ftp.txt ftpact.txt proftpd.txt vsftpd.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_10() {
  echo -n "SRV-012. .netrc 파일 내 호스트 정보 노출 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-012. .netrc 파일 내 호스트 정보 노출 " >> $CREATE_FILE 2>&1
  echo ":: 1. $HOME/.netrc 파일 소유자가 root 또는, 해당 계정인 경우" >> $CREATE_FILE 2>&1
  echo "   2. $HOME/.netrc 파일 권한이 600 이하인 경우" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u`
  FILES="/.netrc"

	for dir in $HOMEDIRS
		do
			for file in $FILES
				do
					if [ -f $dir$file ]
						then
						echo "■ $HOME/.netrc 파일 현황 " >> $CREATE_FILE 2>&1
						echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
						ls -alL $dir$file  >> $CREATE_FILE 2>&1
						echo " " >> $CREATE_FILE 2>&1
						echo "- $dir$file 설정 내용" >> $CREATE_FILE 2>&1
						cat $dir$file | grep -v "^#" >> $CREATE_FILE 2>&1
						else
						echo "설정 내용이 없습니다. " >> nothing.txt
					fi
			done
	done
	echo " " >> $CREATE_FILE 2>&1
	
  if [ -f nothing.txt ]
    then
      echo "/.netrc 파일이 존재하지 않습니다. " >> $CREATE_FILE 2>&1
  fi


	for dir in $HOMEDIRS
	  do
		for file in $FILES
		  do
			if [ -f $dir$file ]
			  then
				if [ `ls -alL $dir$file |  awk '{print $1}' | grep "...-------" | wc -l` -eq 1 ]
				  then       
				echo "GOOD" >> trust.txt
				  else
				echo "BAD" >> trust.txt
				fi
			fi
		done
	done
	echo "GOOD" >> trust.txt

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat trust.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-012. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-012. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi


  rm -rf trust.txt nothing.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_11() {
  echo -n "SRV-013. Anonymous FTP 비활성화 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-013. Anonymous FTP 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: Anonymous FTP (익명 ftp) 접속을 차단한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  if [ -f /etc/vsftpd.conf ]
    then	
	  cat /etc/vsftpd.conf | grep -i  "anonymous_enable"  >> $CREATE_FILE 2>&1
  fi	

  if [ -f /etc/vsftpd/vsftpd.conf ]
    then
    cat /etc/vsftpd/vsftpd.conf | grep -i "anonymous_enable" >> $CREATE_FILE 2>&1		
  fi
  
  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | grep "ftp" | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | grep ftp | grep -v "tftp" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "FTP 서비스 활성화되어 있습니다." >> ftpps.txt
                echo "/etc/xinetd.d/ FTP 구동 정보" >> $CREATE_FILE 2>&1
                ls -alL /etc/xinetd.d | grep ftp | grep -v "tftp" >> $CREATE_FILE 2>&1
                cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
            fi
          done
      fi
    else
      if [ -f /etc/inetd.conf ]
        then
          if [ `cat /etc/inetd.conf | grep -v '#' | grep ftp  | grep -v "tftp" |  wc -l` -gt 0  ]
            then
              echo "FTP 활성화되어 있습니다." >> ftpps.txt
          fi
      fi
  fi

  ps -ef | grep ftp  | grep -v grep | grep -v "tftp" >> ftpps.txt
  echo " " >> $CREATE_FILE 2>&1

  if [ `cat ftpps.txt | grep ftp | grep -v grep | wc -l` -gt 0 ]
    then
      if [ -f /etc/passwd ]
        then
          cat /etc/passwd | grep -w "ftp" >> $CREATE_FILE 2>&1
        else
          echo "/etc/passwd 파일이 존재하지 않습니다. " >> $CREATE_FILE 2>&1
      fi
    else
      echo "☞ FTP 서비스 비활성화되어 있습니다. " >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat ftpps.txt | grep ftp | grep -v grep | wc -l` -gt 0 ]
    then
      if [ `grep -v "^ *#" /etc/passwd | grep -w "ftp" | grep -v "false" | grep -v "nologin"  | wc -l` -gt 0 ]
        then
          echo "★ SRV-013. 결과 : 취약" >> $CREATE_FILE 2>&1
        else
          echo "★ SRV-013. 결과 : 양호" >> $CREATE_FILE 2>&1
      fi
    else
      echo "★ SRV-013. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_12() {
  echo -n "SRV-014. NFS 접근통제  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-014. NFS 접근통제 " >> $CREATE_FILE 2>&1
  echo ":: NFS 서비스를 사용하지 않거나, 사용 시 everyone 공유를 제한한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ `ps -ef | grep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -gt 0 ]
    then
	  ps -ef | grep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" >> $CREATE_FILE 2>&1
      if [ -f /etc/exports ]
        then
          cat /etc/exports  >> $CREATE_FILE 2>&1
        else
          echo "/etc/exports 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
      fi
    else
    echo "NFS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
   
    ls -al /etc/rc*.d/* | grep -i nfs | grep "/S" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
	
  if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    then
      echo "★ SRV-014. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/exports ]
        then
          if [ `cat /etc/exports | grep -v "^#" | grep "/" | wc -l` -eq 0 ]
            then
              echo "★ SRV-014. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-014. 결과 : 수동진단" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-014. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
  fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_13() {
  echo -n "SRV-015. NFS 서비스 비활성화  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-015. NFS 서비스 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: NFS 서비스 관련 데몬이 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ NFS 데몬(nfsd)확인" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ `ps -ef | grep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -gt 0 ]
    then
	  ps -ef | grep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" >> $CREATE_FILE 2>&1
      if [ -f /etc/exports ]
        then
          cat /etc/exports  >> $CREATE_FILE 2>&1
        else
          echo "/etc/exports 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
      fi
    else
      echo "NFS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
    
	ls -al /etc/rc*.d/* | grep -i nfs | grep "/S" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1 

  if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    then
      echo "★ SRV-015. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/exports ]
        then
          if [ `cat /etc/exports | grep -v "^#" | grep "/" | wc -l` -eq 0 ]
            then
              echo "★ SRV-015. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-015. 결과 : 수동진단" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-015. 결과 : 양호"  >> $CREATE_FILE 2>&1
      fi
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_14() {
  echo -n "SRV-016. 불필요한 RPC서비스 구동 여부  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-016. 불필요한 RPC서비스 구동 여부 " >> $CREATE_FILE 2>&1
  echo ":: 불필요한 RPC 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1


  SERVICE_INETD="rpc.cmsd|rpc.ttdbserverd|sadmind|ruserd|walld|sprayd|rstatd|rpc.nisd|rexd|rpc.pcnfsd|rpc.statd|rpc.ypupdated|rpc.rquotad|kcms_server|cachefsd"

  echo "■ inetd.conf 파일에서 RPC 관련 서비스 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/inetd.conf ]
  	then
	    cat /etc/inetd.conf | grep -v "^ *#" | egrep $SERVICE_INETD >> $CREATE_FILE 2>&1
	  else
	    echo "/etc/inetd.conf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  

  echo "■ /etc/xinetd.d 서비스" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD | wc -l` -eq 0 ]
        then
          echo "/etc/xinetd.d RPC 서비스가 없음" >> $CREATE_FILE 2>&1
        else
          ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD >> $CREATE_FILE 2>&1
      fi
    else
      echo "/etc/xinetd.d 디렉터리가 존재하지 않습니다. " >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d에 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo " " > rpc.txt

  SERVICE_INETD="rpc.cmsd|rpc.ttdbserverd|sadmind|ruserd|walld|sprayd|rstatd|rpc.nisd|rexd|rpc.pcnfsd|rpc.statd|rpc.ypupdated|rpc.rquotad|kcms_server|cachefsd"

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/inetd.conf ]
    then
      if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | wc -l ` -eq 0 ]
        then
          echo "GOOD" >> rpc.txt
        else
          echo "BAD" >> rpc.txt
      fi
    else
      echo "GOOD" >> rpc.txt
  fi

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "BAD" >> rpc.txt
              else
                echo "GOOD" >> rpc.txt
            fi
          done
        else
          echo "GOOD" >> rpc.txt
      fi
    else
      echo "GOOD" >> rpc.txt
  fi

  if [ `cat rpc.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-016. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-016. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf rpc.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_15() {
  echo -n "SRV-017. automountd 제거  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-017. automountd 제거 " >> $CREATE_FILE 2>&1
  echo ":: automountd 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ Automount 데몬 확인." >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  ps -ef | egrep 'automountd|autofs' | egrep -v "grep|statdaemon|emi" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1
  ls -al /etc/rc*.d/* | grep -i "auto" | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  if [ `ps -ef | egrep 'automountd|autofs' | egrep -v "grep|statdaemon|emi"  | wc -l` -eq 0 ]
    then
      echo "automount 데몬이 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1


  if [ `ps -ef | egrep 'automountd|autofs' | egrep -v "grep|statdaemon|emi" | wc -l` -eq 0 ]
    then
      echo "★ SRV-017. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-017. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_16() {
  echo -n "SRV-019. tftp, talk 서비스 비활성화  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-019. tftp, talk 서비스 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: tftp, talk, ntalk 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="tftp|talk|ntalk"


  echo "■ inetd.conf 파일에서 tftp, talk 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/inetd.conf ]
  	then
	    cat /etc/inetd.conf | grep -v "^ *#" | egrep $SERVICE_INETD >> $CREATE_FILE 2>&1
	  else
	    echo "/etc/inetd.conf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "■ /etc/xinetd.d 서비스" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD  >> $CREATE_FILE 2>&1
    else
      echo "tftp, talk 서비스가 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d 디렉터리에 tftp, talk, ntalk 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1


  echo " " > service.txt

  if [ -f /etc/inetd.conf ]
    then
      if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | wc -l ` -eq 0 ]
        then
          echo "GOOD" >> service.txt
        else
          echo "BAD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "BAD" >> service.txt
              else
                echo "GOOD" >> service.txt
            fi
          done
        else
          echo "GOOD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  if [ `cat service.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-019. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-019. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf service.txt


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_17() {
  echo -n "SRV-022. 계정의 비밀번호 미 설정 점검  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-022. 계정의 비밀번호 미 설정 점검 " >> $CREATE_FILE 2>&1
  echo ":: 비밀번호 미설정 된 계정이 없을 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "☞ 패스워드 미설정 계정" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  cat /etc/shadow | grep -v '\!\!' | grep -v '\!' | grep -v '\*' | grep -v ':\$' > u40.txt #계정뒤어 패스워드부분이 공란(::)으로 오는 계쩡 확인
  
  if [ `cat u40.txt | wc -l` -ge 1 ]   # 패스워드 미설정 계정 유/무로 양호/취약 판단
	then
		cat u40.txt >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "★ SRV-022. 결과 : 취약" >> $CREATE_FILE 2>&1
	else
		echo "패스워드 미설정 계정이 없습니다." >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "★ SRV-022. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf u40.txt
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_18() {
  echo -n "SRV-025. \$HOME/.rhosts, hosts.equiv 사용 금지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-025. \$HOME/.rhosts, hosts.equiv 사용 금지 " >> $CREATE_FILE 2>&1
  echo ":: login, shell, exec 서비스를 사용하지 않거나, 사용 시 아래와 같은 설정이 적용된 경우 양호" >> $CREATE_FILE 2>&1
  echo "   1. /etc/hosts.equiv 및 $HOME/.rhosts 파일 소유자가 root 또는, 해당 계정인 경우" >> $CREATE_FILE 2>&1
  echo "   2. /etc/hosts.equiv 및 $HOME/.rhosts 파일 권한이 600 이하인 경우" >> $CREATE_FILE 2>&1
  echo "   3. /etc/hosts.equiv 및 $HOME/.rhosts 파일 설정에 '+' 설정이 없는 경우" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="rsh|rlogin|rexec|shell|login|exec"

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 서비스 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD |egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
    then
      ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD  >> $CREATE_FILE 2>&1
    else
      echo "r 서비스가 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d디렉터리에 r 계열 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="rsh|rlogin|rexec|shell|login|exec"

  echo "■ inetd.conf 파일에서 'r' commnad 관련 서비스 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/inetd.conf ]
    then
      cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" >> $CREATE_FILE 2>&1
    else
      echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "r command" > r_temp
              else
                echo "GOOD" >> trust.txt
                result="GOOD"
            fi
          done
        else
          echo "GOOD" >> trust.txt
          result="GOOD"
      fi
    elif [ -f /etc/inetd.conf ]
      then
        if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" |wc -l` -eq 0 ]
          then
            echo "GOOD" >> trust.txt
            result="GOOD"
          else
            echo "r command" > r_temp
        fi
      else
        echo "GOOD" >> trust.txt
        result="GOOD"
  fi


  HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u`
  FILES="/.rhosts"

  

  if [ -s r_temp ]
    then
      if [ -f /etc/hosts.equiv ]
        then
		echo "■ /etc/hosts.equiv 파일 현황 " >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
          ls -alL /etc/hosts.equiv >> $CREATE_FILE 2>&1
          echo " " >> $CREATE_FILE 2>&1
          echo "/etc/hosts.equiv 파일 설정 내용" >> $CREATE_FILE 2>&1
          cat /etc/hosts.equiv >> $CREATE_FILE 2>&1
        else
          echo "/etc/hosts.equiv 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
      fi
    else
      echo " " >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  

  if [ -s r_temp ]
    then
      for dir in $HOMEDIRS
        do
          for file in $FILES
            do
              if [ -f $dir$file ]
                then
					echo "■ $HOME/.rhosts 파일 현황 " >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					ls -alL $dir$file  >> $CREATE_FILE 2>&1
					echo " " >> $CREATE_FILE 2>&1
					echo "- $dir$file 설정 내용" >> $CREATE_FILE 2>&1
					cat $dir$file | grep -v "^#" >> $CREATE_FILE 2>&1
                else
					echo "설정 내용이 없습니다. " >> nothing.txt
              fi
            done
        done
    else
      echo " " >> $CREATE_FILE 2>&1
  fi

  if [ -f nothing.txt ]
    then
      echo "/.rhosts 파일이 존재하지 않습니다. " >> $CREATE_FILE 2>&1
  fi

  if [ -s r_temp ]
    then
      if [ -f /etc/hosts.equiv ]
        then
          if [ `ls -alL /etc/hosts.equiv |  awk '{print $1}' | grep "....------" | wc -l` -eq 1 ]
            then
              echo "GOOD" >> trust.txt
            else
              echo "BAD" >> trust.txt
          fi
          if [ `cat /etc/hosts.equiv | grep "+" | grep -v "grep" | grep -v "^#" | wc -l` -eq 0 ]
            then
              echo "GOOD" >> trust.txt
            else
              echo "BAD" >> trust.txt
          fi
        else
          echo "BAD" >> trust.txt
      fi
    else
      echo "GOOD" >> trust.txt
  fi


  if [ -s r_temp ]
    then
      for dir in $HOMEDIRS
	      do
	        for file in $FILES
	          do
	            if [ -f $dir$file ]
	              then
                  if [ `ls -alL $dir$file |  awk '{print $1}' | grep "....------" | wc -l` -eq 1 ]
                    then
                      echo "GOOD" >> trust.txt
                    else
                      echo "BAD" >> trust.txt
                  fi
                  if [ `cat $dir$file | grep "+" | grep -v "grep" | grep -v "^#" |wc -l ` -eq 0 ]
                    then
                      echo "GOOD" >> trust.txt
                    else
                      echo "BAD" >> trust.txt
                  fi
                fi
            done
        done
    else
      echo "GOOD" >> trust.txt
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat trust.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-025. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-025. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi


  rm -rf trust.txt r_temp nothing.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_19() {
	echo -n "SRV-026. root 계정 원격 접속 제한 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-026. root 계정 원격 접속 제한" >> $CREATE_FILE 2>&1
	echo ":: 원격 서비스를 사용하지 않거나, 사용 시 root 직접 접속을 차단한 경우 양호"    >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	echo "① Telnet 프로세스 데몬 동작 확인 " >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

	if [ `netstat -na | grep -i ":23 " | wc -l` -gt 0 ]
	then
		netstat -na | grep ":23 " >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1 
		echo "☞ Telnet 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1

		echo " " >> $CREATE_FILE 2>&1

		echo "☞ /etc/securetty 현황 " >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

		if [ -f /etc/securetty ]
		then
			cat /etc/securetty | grep -i "pts" >> $CREATE_FILE 2>&1

			if [ `cat /etc/securetty | grep -i "pts" | grep -v '^#' | wc -l` -eq 0 ]
			then
				result_telnet='true'
			else
				result_telnet='false'
			fi
			
		else
			echo "/etc/securetty파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			result_telnet='false'
		fi
		   
		echo " " >> $CREATE_FILE 2>&1
		   
		echo "☞ /etc/pam.d/login 현황 " >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

		if [ -f /etc/pam.d/login ]
		then
			cat /etc/pam.d/login | grep -i "pam_securetty.so" >> $CREATE_FILE 2>&1

			if [ `cat /etc/pam.d/login | grep "pam_securetty.so" | grep -v "#" | wc -l` -eq 0 ]
			then
				result_pam_telnet='false'
			else
				result_pam_telnet='true'
			fi
		else
			echo "☞ /etc/pam.d/login파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			result_pam_telnet='false'
		fi
		
	else
		echo "☞ Telnet 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
		result_telnet='true'
        result_pam_telnet='true'		
	fi
  
  
	echo " " >> $CREATE_FILE 2>&1  
	echo " " >> $CREATE_FILE 2>&1 



	echo "② SSH 프로세스 데몬 동작 확인 " >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

	if [ `ps -ef | grep sshd | grep -v "grep" | wc -l` -eq 0 ]
	then
		echo "☞ SSH 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
		result_sshd='true'

	else
		ps -ef | grep sshd | grep -v "grep" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1 
		echo "☞ SSH 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1

		echo " " >> $CREATE_FILE 2>&1 

		echo "☞ sshd_config파일 확인 " >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

		echo " " > ssh-result.txt

		ServiceDIR="/etc/sshd_config /etc/ssh/sshd_config /usr/local/etc/sshd_config /usr/local/sshd/etc/sshd_config /usr/local/ssh/etc/sshd_config /etc/opt/ssh/sshd_config"

		for file in $ServiceDIR
		do
			if [ -f $file ]
			then
				if [ `cat $file | grep "PermitRootLogin" | grep -v "setting" | wc -l` -gt 0 ]
				then
					cat $file | grep "PermitRootLogin" | grep -v "setting" | awk '{print "SSH 설정파일('${file}'): "}' >> ssh-result.txt
					echo " " >> $CREATE_FILE 2>&1
					cat $file | grep "PermitRootLogin" | grep -v "setting" | awk '{print $0 }' >> ssh-result.txt 

					if [ `cat $file | egrep -i "PermitRootLogin no|PermitRootLogin prohibit-password" | grep -v '^#' | wc -l` -gt 0 ]
						then
							result_sshd='true'
						else
							result_sshd='false'
					fi
					
				else	
					echo "☞ SSH 설정파일($file): PermitRootLogin 설정이 존재하지 않습니다." >> ssh-result.txt
				fi
				
				if [ `cat $file | grep -i "banner" | grep -v "default banner" | wc -l` -gt 0 ]
				then
					cat $file | grep -i "banner" | grep -v "default banner" | awk '{print "SSH 설정파일('${file}'): " $0 }' >> ssh-banner.txt
				else
					echo "☞ ssh 로그인 전 출력되는 배너지정이 되어 있지 않습니다. " >> ssh-banner.txt
				fi	
			fi
		done 
			
		if [ `cat ssh-result.txt | grep -v "^ *$" | wc -l` -gt 0 ]
		then
			cat ssh-result.txt | grep -v "^ *$" >> $CREATE_FILE 2>&1
		else
			echo "SSH 설정파일을 찾을 수 없습니다. (인터뷰/수동진단)" >> $CREATE_FILE 2>&1
		fi
	fi

	echo " " >> $CREATE_FILE 2>&1 
	echo " " >> $CREATE_FILE 2>&1 
  
	if [ $result_telnet='true' -a $result_pam_telnet='true' -a $result_sshd='true' ]
	then
		echo "★ SRV-026. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-026. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	rm -rf ssh-result.txt 

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_20() {
  echo -n "SRV-027. 접속 IP 및 포트 제한 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-027. 접속 IP 및 포트 제한 " >> $CREATE_FILE 2>&1
  echo ":: /etc/hosts.deny 파일에 ALL Deny 설정 후" >> $CREATE_FILE 2>&1
  echo "   /etc/hosts.allow 파일에 접근을 허용할 특정 호스트를 등록한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/hosts.deny ]
    then
      if [ `cat /etc/hosts.deny | grep -v "^#" | wc -l` -eq 0 ]
		then
			echo "☞ /etc/hosts.deny 파일 내용이 없습니다.">> $CREATE_FILE 2>&1
		else
			echo "☞ /etc/hosts.deny 파일 내용" >> $CREATE_FILE 2>&1
			cat /etc/hosts.deny | grep -v "^#" >> $CREATE_FILE 2>&1
		fi
    else
      echo "/etc/hosts.deny 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/hosts.allow ]
    then
      if [ `cat /etc/hosts.allow | grep -v "^#" | wc -l` -eq 0 ]
		then
			echo "☞ /etc/hosts.allow 파일 내용이 없습니다.">> $CREATE_FILE 2>&1
		else
			echo "☞ /etc/hosts.allow 파일 내용" >> $CREATE_FILE 2>&1
			cat /etc/hosts.allow | grep -v "^#"  >> $CREATE_FILE 2>&1
		fi
    else
      echo "/etc/hosts.allow 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/hosts.deny ]
    then
      if [ `cat /etc/hosts.deny | grep -v "^#" | sed 's/ *//g' | grep "ALL:ALL" | wc -l` -gt 0 ]
        then
          echo "GOOD" > IP_ACL.txt
        else
          echo "BAD" > IP_ACL.txt
      fi
    else
      echo "BAD" > IP_ACL.txt
  fi

  if [ -f /etc/hosts.allow ]
    then
      if [ `cat /etc/hosts.allow | grep -v "^#" | sed 's/ *//g' | grep -v "ALL:ALL" | wc -l` -gt 0 ]
        then
          echo "GOOD" >> IP_ACL.txt
        else
          echo "BAD" >> IP_ACL.txt
      fi
    else
      echo "BAD" >> IP_ACL.txt
  fi  

  if [ `cat IP_ACL.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-027. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-027. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi


rm -rf IP_ACL.txt


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_21() {
  echo -n "SRV-030. Finger 서비스 비활성화 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-030. Finger 서비스 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: Finger 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="finger"
  
	echo "■ finger 포트 활성화 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ `netstat -na | grep :79 | grep -i listen | wc -l` -ge 1 ]
		then
			echo "finger 서비스 포트가 활성화되어 있습니다." >>$CREATE_FILE 2>&1
			echo "BAD" >> service.txt
	else
		echo " " >> $CREATE_FILE 2>&1
		
		echo " finger 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
	fi
	echo " " >> $CREATE_FILE 2>&1
	
  echo "■ inetd.conf 파일에서 finger 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/inetd.conf ]
  	then
	    cat /etc/inetd.conf | grep -v "^ *#" | egrep $SERVICE_INETD >> $CREATE_FILE 2>&1
	  else
	    echo "/etc/inetd.conf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "■ /etc/xinetd.d 서비스" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD  >> $CREATE_FILE 2>&1
    else
      echo "finger 서비스가 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d디렉터리에 finger 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1


  echo " " > service.txt

  if [ -f /etc/inetd.conf ]
    then
      if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | wc -l ` -eq 0 ]
        then
          echo "GOOD" >> service.txt
        else
          echo "BAD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "BAD" >> service.txt
              else
                echo "GOOD" >> service.txt
            fi
          done
        else
          echo "GOOD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  if [ `cat service.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-030. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-030. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf service.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_22() {
  echo -n "SRV-035. r 계열 서비스 비활성화  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-035. r 계열 서비스 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: r 계열 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="shell|login|exec|rsh|rlogin|rexec"
	echo " " > 23.txt
  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 서비스 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD |egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
    then
      ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD  >> $CREATE_FILE 2>&1
    else
      echo "r 서비스가 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d디렉터리에 r 계열 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="shell|login|exec|rsh|rlogin|rexec"

  echo "■ inetd.conf 파일에서 'r' commnad 관련 서비스 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/inetd.conf ]
    then
      cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" >> $CREATE_FILE 2>&1
    else
      echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "★ SRV-035. 결과 : 취약" >> 23.txt 2>&1
                
              else
                echo "★ SRV-035. 결과 : 양호" >> 23.txt 2>&1
            fi
          done
        else
          echo "★ SRV-035. 결과 : 양호" >> 23.txt 2>&1
      fi
    elif [ -f /etc/inetd.conf ]
      then
        if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | egrep -v "grep|klogin|kshell|kexec" |wc -l` -eq 0 ]
          then
            echo "★ SRV-035. 결과 : 양호" >> 23.txt 2>&1
          else
            echo "★ SRV-035. 결과 : 취약" >> 23.txt 2>&1
            
        fi
      else
        echo "★ SRV-035. 결과 : 양호" >> 23.txt 2>&1
  fi
    if [ `cat 23.txt | grep "BAD" | wc -l` -eq 0 ]
    then
       echo "★ SRV-035. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
       echo "★ SRV-035. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi
  
	rm -rf 23.txt 
  rm -rf r_temp

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_23() {
  echo -n "SRV-036. DoS 공격에 취약한 서비스 비활성화  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-036. DoS 공격에 취약한 서비스 비활성화 " >> $CREATE_FILE 2>&1
  echo ":: DoS 공격에 취약한 echo, discard, daytime, chargen 서비스가 비활성화 된 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE_INETD="echo|discard|daytime|chargen"


  echo "■ inetd.conf 파일에서 echo, discard, daytime, chargen 상태" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/inetd.conf ]
  	then
	    cat /etc/inetd.conf | grep -v "^ *#" | egrep $SERVICE_INETD >> $CREATE_FILE 2>&1
	  else
	    echo "/etc/inetd.conf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "■ /etc/xinetd.d 서비스" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  if [ `ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      ls -alL /etc/xinetd.d/* | egrep $SERVICE_INETD  >> $CREATE_FILE 2>&1
    else
      echo "DoS 공격에 취약한 서비스가 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo "■ /etc/xinetd.d 내용 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
      for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
      do
        echo " $VVV 파일" >> $CREATE_FILE 2>&1
        cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
        echo "   " >> $CREATE_FILE 2>&1
      done
    else
      echo "xinetd.d 디렉터리에 DoS에 취약한 서비스 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1


  echo " " > service.txt

  if [ -f /etc/inetd.conf ]
    then
      if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | wc -l ` -eq 0 ]
        then
          echo "GOOD" >> service.txt
        else
          echo "BAD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | egrep $SERVICE_INETD | grep -v "ssf" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "BAD" >> service.txt
              else
                echo "GOOD" >> service.txt
            fi
          done
        else
          echo "GOOD" >> service.txt
      fi
    else
      echo "GOOD" >> service.txt
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat service.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-036. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-036. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf service.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_24() {
  echo -n "SRV-037. FTP 서비스 구동 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-037. FTP 서비스 구동 점검 " >> $CREATE_FILE 2>&1
  echo ":: FTP 서비스가 비활성화 되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  find /etc -name "proftpd.conf" > proftpd.txt
  find /etc -name "vsftpd.conf" > vsftpd.txt
  profile=`cat proftpd.txt`
  vsfile=`cat vsftpd.txt`

  echo "① /etc/services 파일에서 포트 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  if [ `cat /etc/services | awk -F" " '$1=="ftp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" | wc -l` -gt 0 ]
    then
	    cat /etc/services | awk -F" " '$1=="ftp" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" >> $CREATE_FILE 2>&1
    else
	    echo "(1)/etc/service파일: 포트 설정 X (Default 21번 포트)" >> $CREATE_FILE 2>&1
  fi

  if [ -s vsftpd.txt ]
    then
	    if [ `cat $vsfile | grep "listen_port" | grep -v "^#" | awk '{print "(3)VsFTP 포트: " $1 "  " $2}' | wc -l` -gt 0 ]
	      then
		      cat $vsfile | grep "listen_port" | grep -v "^#" | awk '{print "(3)VsFTP 포트: " $1 "  " $2}' >> $CREATE_FILE 2>&1
	      else
		      echo "(2)VsFTP 포트: 포트 설정 X (Default 21번 포트 사용중)" >> $CREATE_FILE 2>&1
	    fi
    else
	    echo "(2)VsFTP 포트: VsFTP가 설치되어 있지 않습니다." >> $CREATE_FILE 2>&1
  fi


  if [ -s proftpd.txt ]
    then
	    if [ `cat $profile | grep "Port" | grep -v "^#" | awk '{print "(2)ProFTP 포트: " $1 "  " $2}' | wc -l` -gt 0 ]
	      then
		      cat $profile | grep "Port" | grep -v "^#" | awk '{print "(2)ProFTP 포트: " $1 "  " $2}' >> $CREATE_FILE 2>&1
	      else
		      echo "(3)ProFTP 포트: 포트 설정 X (/etc/service 파일에 설정된 포트 사용중)" >> $CREATE_FILE 2>&1
	    fi
    else
	    echo "(3)ProFTP 포트: ProFTP가 설치되어 있지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  echo "② 서비스 포트 활성화 여부 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  ################# /etc/services 파일에서 포트 확인 #################

  if [ `cat /etc/services | awk -F" " '$1=="ftp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}' | wc -l` -gt 0 ]
    then
	    port=`cat /etc/services | awk -F" " '$1=="ftp" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}'`;
	    
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable" > ftpenable.txt
	    fi
    else
	    netstat -nat | grep ":21 " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
	    echo "ftp disable" > ftpenable.txt
  fi

  ################# vsftpd 에서 포트 확인 ############################

  if [ -s vsftpd.txt ]
    then
	    if [ `cat $vsfile | grep "listen_port" | grep -v "^#" | awk -F"=" '{print $2}' | wc -l` -eq 0 ]
	      then
		      port=21
	      else
		      port=`cat $vsfile | grep "listen_port" | grep -v "^#" | awk -F"=" '{print $2}'`
	    fi
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable" >> ftpenable.txt
	    fi
	  else
	    echo "ftp disable" >> ftpenable.txt
  fi

  ################# proftpd 에서 포트 확인 ###########################

  if [ -s proftpd.txt ]
    then
	    port=`cat $profile | grep "Port" | grep -v "^#" | awk '{print $2}'`
	    
	    if [ `netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$port " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "ftp enable"  >> ftpenable.txt
		    else
		      echo "ftp disable" >> ftpenable.txt
	    fi
	  else
	    echo "ftp disable" >> ftpenable.txt
  fi
  
	if [ `cat ftpenable.txt | grep -i "ftp disable" | wc -l` -eq 3 ]
		then
			echo "서비스 포트가 활성화 되어 있지 않습니다." >> $CREATE_FILE 2>&1
	fi 
  echo " " >> $CREATE_FILE 2>&1
  
  echo $ftpenable >> $CREATE_FILE

  if [ `cat ftpenable.txt | grep "enable" | wc -l` -gt 0 ]
    then
      echo "★ SRV-037. 결과 : 취약" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-037. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf proftpd.txt vsftpd.txt ftpenable.txt


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_25() {
	echo -n "SRV-039. 불필요한 Tmax WebtoB 서비스 구동 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-039. 불필요한 Tmax WebtoB 서비스 구동 여부" >> $CREATE_FILE 2>&1
	echo ":: 불필요한 WebtoB 서비스를 사용하고 있는 경우 취약 " >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	echo "① WebtoB 프로세스 확인" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ `ps -ef | grep webtob | grep -v "grep" | grep -v "su" | grep -v "bash"| wc -l` -eq 0 ]
	  then
	  echo "WebtoB 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
	  else
  	    ps -ef | grep webtob | grep -v "grep" | grep -v "su" | grep -v "bash" >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
	echo "② WebtoB 계정 쉘 확인(WebtoB 계정에 false 또는 nologin 설정시 양호)" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	
	if [ `cat /etc/passwd | awk -F: '$1=="webtob"' | egrep "false|nologin" | wc -l` -gt 0 ]
    then
      result12='good'
    else
      result12='Vulnerability'
	fi  
  
	if [ `cat /etc/passwd | awk -F: '$1=="webtob"' | wc -l` -gt 0 ]
    then
	    cat /etc/passwd | awk -F: '$1=="webtob"' >> $CREATE_FILE 2>&1
    else
	    echo "WebtoB 계정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
		result61='good'
	fi
  
	if [ `ps -ef | grep webtob | grep -v "grep" | grep -v "su" | grep -v "bash"| wc -l` -eq 0 ]
	  then
	  	  echo " " >> $CREATE_FILE 2>&1
		  echo "★ SRV-039. 결과 : 양호" >> $CREATE_FILE 2>&1
	  else
		if [ $result12 = 'good' ]; 
		  then
		    result12='양호'
			echo "★ SRV-039. 결과 : "$result12 >> $CREATE_FILE 2>&1
		  else
		    result12='수동진단'
		    echo "★ SRV-039. 결과 : "$result12 >> $CREATE_FILE 2>&1
		fi
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_26() {
  echo -n "SRV-040. Apache 디렉토리 리스팅 제거  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-040. Apache 디렉토리 리스팅 제거 " >> $CREATE_FILE 2>&1
  echo ":: 디렉터리 검색 기능을 사용하지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  if [ $web = 'default' ]; then
	echo "☞ Apache 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
	echo "★ SRV-040. 결과 : N/A" >> $CREATE_FILE 2>&1
  else
	if [ $path = 'ok' ]
			then
				if [ `cat $conf |grep -i Indexes | grep -i -v '\-Indexes' | grep -v '\#'|wc -l` -eq 0 ]; then
					result1_26='Good'
					echo "Indexes 설정 확인 -" $conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "DocumentRoot" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "<Directory|Indexes|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ Indexes 옵션이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				else
					result1_26='vulnerable'
					echo "Indexes 설정 확인 -" $conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "DocumentRoot" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "<Directory|Indexes|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ Indexes 옵션이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				fi
			else
				result1_26='interview'
				echo "Indexes 설정 확인" >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
		fi
		if [ -f $apache/conf.d/userdir.conf ]
			then
				if [ `cat $apache/conf.d/userdir.conf | grep -i Indexes | grep -i -v '\-Indexes' | grep -v '\#'| wc -l` -eq 0 ]; then
					result1_26='Good'
					echo "Indexes 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|Indexes|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ Indexes 옵션이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				else
					echo "Indexes 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					result1_26='vulnerable'
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|Indexes|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ Indexes 옵션이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				fi
			else
				echo "Indexes 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
		fi		
		if [ $result1_26 = 'vulnerable' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-040. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ $result1_26 = 'interview' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-040. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-040. 결과 : 양호" >> $CREATE_FILE 2>&1
		fi
  
	fi
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
  }
  
U_27() {
  echo -n "SRV-042. Apache 상위 디렉토리 접근 금지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-042. Apache 상위 디렉토리 접근 금지 " >> $CREATE_FILE 2>&1
  echo ":: 상위 디렉터리에 이동 제한을 설정한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ $web = 'default' ]; then
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
    echo "★ SRV-042. 결과 : N/A" >> $CREATE_FILE 2>&1	
  else
	if [ $path = 'ok' ]
			then
				if [ `cat $conf | grep -i "AllowOverride" | grep -v '#' | grep -i "None" | wc -l` -eq 0 ]; then
					result_27='Good'
					echo "AllowOverride 설정 확인 -" $conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "<Directory|AllowOverride|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ None 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				else
					result_27='vulnerable'
					echo "AllowOverride 설정 확인 -" $conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					cat $conf | egrep -i "<Directory|AllowOverride|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ None 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				fi
			else
				result_27='interview'
				echo "Indexes 설정 확인" >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
		fi		
		if [ -f $apache/conf.d/userdir.conf ]
			then
				if [ `cat $apache/conf.d/userdir.conf | grep -i "AllowOverride" | grep -v '#' | grep -i "None" | wc -l` -eq 0 ]; then
					result_27='Good'
					echo "AllowOverride 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|AllowOverride|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ None 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				else
					result_27='vulnerable'
					echo "AllowOverride 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|AllowOverride|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ None 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				fi
			else
				echo "AllowOverride 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
		fi		
		if [ $result_27 = 'vulnerable' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-042. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ $result_27 = 'interview' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-042. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "사용자 사용자 인증 설정이 되어있는 파일을 찾아 설정값을 확인이 필요합니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-042. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		fi
	fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_28() {
  echo -n "SRV-043. Apache 불필요한 파일 제거 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-043. Apache 불필요한 파일 제거 " >> $CREATE_FILE 2>&1
  echo ":: 메뉴얼 파일 및 디렉터리가 제거되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ $web = 'httpd' ];then
	if [ $path = 'ok' ]; then
		if [ `find "$svrroot" -name 'manual'|wc -l` -eq 0 ]
		then
			echo "Manual 디렉터리가 존재하지 않습니다." >> $CREATE_FILE 2>&1
			result28='Good'
		else
			find "$svrroot" -name 'manual' >> $CREATE_FILE
			result28='Vulnerability'
		fi
		if [ $result28 = 'Good' ]; then
			
			echo "★ SRV-043. 결과 : 양호" >> $CREATE_FILE 2>&1	
		else
			echo "★ SRV-043. 결과 : 취약" >> $CREATE_FILE 2>&1	
		fi
	else
		echo "Manual 디렉터리 확인" $conf >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
		echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
		echo ' ' >> $CREATE_FILE 2>&1
		echo ' ' >> $CREATE_FILE 2>&1
		echo "★ SRV-043. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		echo ' ' >> $CREATE_FILE 2>&1
		echo ' ' >> $CREATE_FILE 2>&1
	fi
  else
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
	echo "★ SRV-043. 결과 : N/A" >> $CREATE_FILE 2>&1	
  fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_29() {
  echo -n "SRV-044. Apache 파일 업로드 및 다운로드 제한 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-044. Apache 파일 업로드 및 다운로드 제한 " >> $CREATE_FILE 2>&1
  echo ":: 파일 업로드 및 다운로드를 제한한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
    result_29='bad'
    
	if [ $web = 'default' ];
	then
		echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
		echo ' ' >> $CREATE_FILE 2>&1	
	else
		if [ $path = 'ok' ]
		then 
			if [ `cat $conf | grep -i "LimitRequestBody" | grep -v '^#' | wc -l` -eq 0 ];
			then
				echo "LimitRequestBody 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "LimitRequestBody " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ 파일 업로드 및 다운로드 제한 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			else
				result_29='good'
				echo "LimitRequestBody 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "LimitRequestBody " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ LimitRequestBody 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi
		else
			result_29='interview'
			echo "LimitRequestBody 설정 확인" >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi		
	
		if [ -f $apache/conf.d/userdir.conf ]
		then
			if [ `cat $apache/conf.d/userdir.conf | grep -i "LimitRequestBody" | grep -v '^#' | wc -l` -eq 0 ]; then
				echo "LimitRequestBody 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $apache/conf.d/userdir.conf | egrep -i "LimitRequestBody " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ FollowSymLinks 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			else
				result_29='good'
				echo "FollowSymLinks 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $apache/conf.d/userdir.conf | egrep -i "LimitRequestBody " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ LimitRequestBody 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi
		else
			echo "LimitRequestBody 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi	
	fi

	if [ $web = 'default' ];
	then
		echo "★ SRV-044. 결과 : N/A" >> $CREATE_FILE 2>&1	
	else 
		if [ $result_29 = 'good' -o $result_29 = 'interview' ]
		then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-044. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-044. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_30() {
  echo -n "SRV-045. Apache 웹 프로세스 권한 제한 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-045. Apache 웹 프로세스 권한 제한 " >> $CREATE_FILE 2>&1
  echo ":: Apache 데몬이 root 권한으로 구동되지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ $web = 'httpd' ];then
		if [ `ps -ef | egrep -i "httpd|apache2" | grep -v grep | grep -v root | wc -l` -eq 0 ]; then
			ps -ef | egrep -i "httpd|apache2" | grep -v grep >>  $CREATE_FILE 2>&1
			echo ' ' >>  $CREATE_FILE 2>&1
			echo '☞ root계정으로 Apache 서비스를 구동하고 있습니다.' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-045. 결과 : 취약" >> $CREATE_FILE 2>&1
		else
			ps -ef | egrep -i "httpd|apache2" | grep -v grep >>  $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo '☞ root계정으로 Apache 서비스를 구동하지 않습니다.' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-045. 결과 : 양호" >> $CREATE_FILE 2>&1
		fi
  else
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
	echo "★ SRV-045. 결과 : N/A" >> $CREATE_FILE 2>&1	
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_31() {
  echo -n "SRV-046. Apache 웹 서비스 영역의 분리 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-046. Apache 웹 서비스 영역의 분리 " >> $CREATE_FILE 2>&1
  echo ":: DocumentRoot를 별도의 디렉터리로 지정한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ $web = 'default' ]; then
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
    echo "★ SRV-046. 결과 : N/A" >> $CREATE_FILE 2>&1	
  else
		if [ $path = 'ok' ]
		then
			if [ `cat $conf | grep -i "DocumentRoot" | grep -v '#' | grep -i "$apache/htdocs" | wc -l` -eq 0 ]; then
				result_31='Good'
				echo "DocumentRoot 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ 웹 서비스 영역이 분리되어 있습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			else
				result_31='vulnerable'
				echo "DocumentRoot 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ 웹 서비스 영역이 분리되어있지 않습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi
		else
			result_31='interview'
			echo "DocumentRoot 설정 확인 -" $conf >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi		
		if [ -f $apache/conf.d/userdir.conf ]
		then
			if [ `cat $apache/conf.d/userdir.conf | grep -i "DocumentRoot" | grep -v '#' | grep -i "$apache/htdocs" | wc -l` -eq 0 ]; then
				result_31='Good'
				echo "DocumentRoot 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ 웹 서비스 영역이 분리되어 있습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			else
				result_31='vulnerable'
				echo "DocumentRoot 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ 웹 서비스 영역이 분리되어있지 않습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi
		else
			echo "DocumentRoot 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi		
		
		if [ $result_31 = 'vulnerable' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-046. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ $result_31 = 'interview' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-046. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-046. 결과 : 양호" >> $CREATE_FILE 2>&1
		fi
	fi


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_32() {
  echo -n "SRV-047. Apache 링크 사용금지 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-047. Apache 링크 사용금지 여부 " >> $CREATE_FILE 2>&1
  echo ":: 심볼릭 링크, aliases 사용을 제한한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ $web = 'default' ]; then
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo ' ' >> $CREATE_FILE 2>&1
    echo "★ SRV-047. 결과 : N/A" >> $CREATE_FILE 2>&1	
  else
		if [ $path = 'ok' ]
		then
			if [ `cat $conf | grep -i "FollowSymLinks" | grep -iv "\-FollowSymLinks" | grep -v '#' | wc -l` -eq 0 ]; then
				result_32='Good'
				echo "FollowSymLinks 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "FollowSymLinks " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "<Directory|FollowSymLinks|</Directory" >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ FollowSymLinks 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			else
				result_32='vulnerable'
				echo "FollowSymLinks 설정 확인 -" $conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "FollowSymLinks " >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				cat $conf | egrep -i "<Directory|FollowSymLinks|</Directory" >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo '☞ FollowSymLinks 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi
		else
			result_32='interview'
			echo "FollowSymLinks 설정 확인 -" $conf >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi		
		if [ -f $apache/conf.d/userdir.conf ]
			then
				if [ `cat $apache/conf.d/userdir.conf | grep -i "FollowSymLinks" | grep -iv "\-FollowSymLinks" | grep -v '#' | wc -l` -eq 0 ]; then
					result_32='Good'
					echo "FollowSymLinks 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|FollowSymLinks|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ FollowSymLinks 설정이 적용되어 있지 않습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				else
					result_32='vulnerable'
					echo "FollowSymLinks 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
					echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "DocumentRoot " >> $CREATE_FILE 2>&1
					cat $apache/conf.d/userdir.conf | egrep -i "<Directory|FollowSymLinks|</Directory" >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo '☞ FollowSymLinks 설정이 적용되어 있습니다.' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
					echo ' ' >> $CREATE_FILE 2>&1
				fi
			else
				echo "FollowSymLinks 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
		fi		
		
		if [ $result_32 = 'vulnerable' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-047. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ $result_32 = 'interview' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-047. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-047. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi
fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_33() {
  echo -n "SRV-060. 미흡한 Apache Tomcat 기본 계정 사용 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-060. 미흡한 Apache Tomcat 기본 계정 사용 여부" >> $CREATE_FILE 2>&1
  echo ":: 관리자 페이지가 비활성화 되어 있거나 기본계정을 사용하지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  ps -ef | grep tomcat|awk -F'Dcatalina.home=' '{print $2}' | awk '{print $1}' | grep -v ^$ >> srv060.txt
  
  tomcat=`ps -ef | grep tomcat|awk -F'Dcatalina.home=' '{print $2}' | awk '{print $1}' | grep -v ^$`
    
  if [ `cat srv060.txt | wc -l` -gt 0 ]
	then
		version=`sh "$tomcat"/bin/catalina.sh version |grep version|awk -F':' '{print $2}'|awk -F'/' '{print $2}'`
  fi
  
  result1_1="Good"
  
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
	if [ `cat srv060.txt | wc -l` -gt 0 ]
        then
            echo "☞ Tomcat 프로세스" >> $CREATE_FILE 2>&1
            ps -ef | grep 'tomcat' | grep -v 'grep' >> $CREATE_FILE 2>&1
			pstomcat=1
        else
            echo "☞ Tomcat 프로세스가 없습니다." >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			pstomcat=0
    fi
		
	if [ $pstomcat -gt 0 ]
		then
		if [ "$version" = "6" ]
			then
				server_path="$tomcat"
				conf="$server_path/conf"
			else
				if [ -d "$tomcat"/server ]
					then
						server_path="$tomcat"/server
						conf="$server_path/conf"
					else
						server_path="$tomcat"
						conf="$server_path/conf"
				fi
		fi
	fi

	echo " " >> $CREATE_FILE 2>&1
	
	if [ `ls $server_path/webapps |grep -i admin|wc -l` -ge 1 -o `ls $server_path/webapps|grep -i manager|wc -l` -ge 1 ]
		then
			echo "☞ 관리자 페이지가 존재 합니다." >> $CREATE_FILE 2>&1
			admin=1
		else
			echo "☞ 관리자 페이지가 존재하지 않습니다." >> $CREATE_FILE 2>&1
			admin=0
	fi

	if [ $admin -eq 1 ]
		then
			count=`cat "$conf"/tomcat-users.xml | sed 's/^ */ /' | grep -v '^ *$' | tr -d '\n' | sed 's/<!--/\n/g' | sed 's/.*-->/\n/g' | sed 's/> </>\n</g' | grep -v '^ *$' | sed 's/^ *</</g'| awk 'BEGIN {IGNORECASE=1}/username|password/ {print $0}' | wc -l`
			count=`expr $count`

			until [ $count -eq 0 ];
			do
	
			user=`for line in \`cat "$conf"/tomcat-users.xml | sed 's/^ */ /' | grep -v '^ *$' | tr -d '\n' | sed 's/<!--/\n/g' | sed 's/.*-->/\n/g' | sed 's/> </>\n</g' | grep -v '^ *$' | sed 's/^ *</</g' | awk '/username|password/' | tr -d '\"' | grep -n "" | grep "${count}:" | sed -e 's/\(.*\)\=\(.*\)/\1=\2/'\`; do echo $line | grep username | awk -F= '{print $2}';done`
			pass=`for line in \`cat "$conf"/tomcat-users.xml | sed 's/^ */ /' | grep -v '^ *$' | tr -d '\n' | sed 's/<!--/\n/g' | sed 's/.*-->/\n/g' | sed 's/> </>\n</g' | grep -v '^ *$' | sed 's/^ *</</g' | awk '/username|password/' | tr -d '\"' | grep -n "" | grep "${count}:" | sed -e 's/\(.*\)\=\(.*\)/\1=\2/'\`; do echo $line | grep password | awk -F= '{print $2}';done`
			roles=`for line in \`cat "$conf"/tomcat-users.xml | sed 's/^ */ /' | grep -v '^ *$' | tr -d '\n' | sed 's/<!--/\n/g' | sed 's/.*-->/\n/g' | sed 's/> </>\n</g' | grep -v '^ *$' | sed 's/^ *</</g' | awk '/username|password/' | tr -d '\"' | grep -n "" | grep "${count}:" | sed -e 's/\(.*\)\=\(.*\)/\1=\2/'\`; do echo $line | grep roles | tr -d '/>' | awk -F= '{print $2}';done`
	
				if [ \( "$user" = "$pass" \) -o \( `echo "$pass" | grep "<must-be-changed>" | wc -l` -eq 1 \) ]; then
					if [ `echo "$roles" | grep 'admin\|manager\|tomcat' | wc -l` -eq 1 ]; then
					result1_1='Vulnerability'
					fi
				fi
			count=`expr $count - 1`
			done
		if [ "$result1_1" = "Vulnerability" ]
			then
				echo "☞ tomcat-users.xml 설정에 기본계정을 사용 하고 있습니다." >> $CREATE_FILE 2>&1
			else
				echo "☞ tomcat-users.xml 설정에 기본계정을 사용 하고 있지 않습니다." >> $CREATE_FILE 2>&1
		fi
	fi

	echo " " >> $CREATE_FILE 2>&1
	if [ "$result1_1" = "Vulnerability" ]; then
			result1_2='취약' 
		else
			result1_2='양호'
	fi

	rm -rf srv060.txt
	echo "★ SRV-060. 결과 : "$result1_2 >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_34() {
  echo -n "SRV-061. DNS Inverse Query 설정 오류  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-061. DNS Inverse Query 설정 오류" >> $CREATE_FILE 2>&1
  echo ":: DNS 서비스를 사용하지 않거나 주기적으로 패치를 관리하고 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  DNSPR=`ps -ef | egrep -i "/named|/in.named" | grep -v "grep" | awk 'BEGIN{ OFS="\n"} {i=1; while(i<=NF) {print $i; i++}}'| grep "/" | uniq`
  DNSPR=`echo $DNSPR | awk '{print $1}'`

  echo "① DNS 포트확인 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `cat /etc/services | awk -F" " '$1=="domain" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" | wc -l` -ge 1 ]
	then 
		cat /etc/services | awk -F" " '$1=="domain" {print "(1)/etc/service파일:" $1 " " $2}' | grep "tcp" >> $CREATE_FILE 2>&1
	else
		echo "(1)/etc/service 파일 : 포트설정 X" >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  
  echo "② DNS 서비스 포트 활성화 여부 " >> $CREATE_FILE 2>&1
    if [ `cat /etc/services | awk -F" " '$1=="domain" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}' | wc -l` -ge 1 ]
    then
	    dnsport=`cat /etc/services | awk -F" " '$1=="domain" {print $1 "   " $2}' | grep "tcp" | awk -F" " '{print $2}' | awk -F"/" '{print $1}'`;

	    if [ `netstat -nat | grep ":$dnsport " | grep -i "^tcp" | grep -i "LISTEN" | wc -l` -gt 0 ]
	      then
		      netstat -nat | grep ":$dnsport " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
		      echo "DNS 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
			  echo " " >> $CREATE_FILE 2>&1
			  echo "DNSENABLE" > dnsenable.txt
				if [ -f $DNSPR ]
					then
						echo "BIND 버전 확인" >> $CREATE_FILE 2>&1
						echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
						$DNSPR -v | grep BIND >> $CREATE_FILE 2>&1
					else
						echo "$DNSPR 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				fi
		   else
		      echo "DNS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1	   
			  echo "DNSDISABLE" > dnsenable.txt
		fi	  
    else
	    netstat -nat | grep ":53 " | grep -i "^tcp" | grep -i "LISTEN" >> $CREATE_FILE 2>&1
	    echo "DNS 서비스가 비활성화되어 있습니다.">> $CREATE_FILE 2>&1
		echo "DNSDISABLE" > dnsenable.txt
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
    then
      echo "★ SRV-061. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-061. 결과 : 수동진단" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_35() {
  echo "SRV-062. BIND 서버 버전 노출 여부  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-062. BIND 서버 버전 노출 여부 " >> $CREATE_FILE 2>&1
  echo ":: /etc/named.conf 파일의 version 설정에서 unknown으로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "① DNS 서비스 활성화 여부 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  	if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
      then
        echo "DNS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
      else
       echo "DNS 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	fi
	echo " " >> $CREATE_FILE 2>&1
  
  
  echo "② /etc/named.conf 설정값 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	if [ -f /etc/named.conf ]; then
		if [ `cat /etc/named.conf | grep -i "version" | grep -v '^#' | wc -l` -eq 1 ]
		then
			cat /etc/named.conf | grep -i "version" | grep -v '^#' >> $CREATE_FILE 2>&1
		else
			echo "DNS named.conf version 설정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
		fi
		else
			echo "DNS named.conf 설정 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
	  then
	    echo "★ SRV-062. 결과 : 양호" >> $CREATE_FILE 2>&1
	  else
		if [ `cat /etc/named.conf | grep "version" | grep -v '^#' | awk '{print $2}' | sed s/\"//g | sed s/\;//g | grep [0-9] | wc -l` -eq 0 ]
		  then
			if [ `cat /etc/named.conf | grep "version" | wc -l` -ge 1 ]
				then
					echo "★ SRV-062. 결과 : 양호" >> $CREATE_FILE 2>&1
				else
		    		echo "★ SRV-062. 결과 : 취약" >> $CREATE_FILE 2>&1
			fi
		  else
		    echo "★ SRV-062. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_36() {
	echo -n "SRV-063. DNS Recursive Query 설정 미흡 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-063. DNS Recursive Query 설정 미흡" >> $CREATE_FILE 2>&1
	echo ":: DNS서버를 사용하지 않거나, Open DNS(recursion query) 취약점이 존재하지 않는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

  echo "① DNS 서비스 활성화 여부 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  	if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
      then
        echo "DNS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
      else
       echo "DNS 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	fi
	echo " " >> $CREATE_FILE 2>&1
	
	echo "② DNS named.conf 파일 설정 현황" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

	if [ -f /etc/named.conf ]; 
	then
		if [ `cat /etc/named.conf | grep "recursion no" | grep -v '^#' | wc -l` -gt 0 ]
		then
			cat /etc/named.conf | egrep -i "recursion no" | grep -v '^#' >> $CREATE_FILE 2>&1 
		else
			echo "DNS named.conf Recursion 기능 설정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			cat /etc/named.conf | egrep -i "acl|allow-recursion" | grep -v '^#' >> $CREATE_FILE 2>&1
		fi
	else
		echo "DNS named.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
	  then
	    echo "★ SRV-063. 결과 : 양호" >> $CREATE_FILE 2>&1
	  else
		if [ -f /etc/named.conf ]; then
			if [ `cat /etc/named.conf | grep "recursion no" | grep -v '^#' | wc -l` -gt 0 ]
			then
				echo "★ SRV-063. 결과 : 양호" >> $CREATE_FILE 2>&1
			else
				echo "★ SRV-063. 결과 : 수동진단" >> $CREATE_FILE 2>&1
			fi
		else
			echo "★ SRV-063. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi
			
			
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_37() {
  echo -n "SRV-064. DNS 보안 버전 패치  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-064. DNS 보안 버전 패치 " >> $CREATE_FILE 2>&1
  echo ":: DNS 서비스를 사용하지 않거나 주기적으로 패치를 관리하고 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  DNSPR=`ps -ef | egrep -i "/named|/in.named" | grep -v "grep" | awk 'BEGIN{ OFS="\n"} {i=1; while(i<=NF) {print $i; i++}}'| grep "/" | uniq`
  DNSPR=`echo $DNSPR | awk '{print $1}'`

  if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -ge 1 ]
    then
      if [ -f $DNSPR ]
        then
          echo "BIND 버전 확인" >> $CREATE_FILE 2>&1
          echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
          $DNSPR -v | grep BIND >> $CREATE_FILE 2>&1
        else
          echo "$DNSPR 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
      fi
    else
      echo "☞ DNS 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1


  if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
    then
      echo "★ SRV-064. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f $DNSPR ]
        then
          if [ `$DNSPR -v | grep BIND | egrep '8.4.6 | 8.4.7 | 9.2.8-P1 | 9.3.4-P1 | 9.4.1-P1 | 9.5.0a6 | 9.9.9-P4 | 9.10.4-P4 | 9.11.0-P1' |wc -l` -gt 0 ]
            then
              echo "★ SRV-064. 결과 : 양호" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-064. 결과 : 수동진단" >> $CREATE_FILE 2>&1
          fi
        else
          echo "★ SRV-064. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      fi
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_38() {
  echo -n "SRV-065. NIS, NIS+ 점검  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-065. NIS, NIS+ 점검 " >> $CREATE_FILE 2>&1
  echo ":: NIS 서비스가 비활성화 되어 있거나, 필요 시 NIS+를 사용하는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  SERVICE="ypserv|ypbind|ypxfrd|rpc.yppasswdd|rpc.ypupdated"

  if [ `ps -ef | egrep $SERVICE | grep -v "grep" | wc -l` -eq 0 ]
    then
	    echo "☞ NIS, NIS+ 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
    else
	    ps -ef | egrep $SERVICE | grep -v "grep" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `ps -ef | egrep $SERVICE | grep -v "grep" | wc -l` -eq 0 ]
    then
      echo "★ SRV-065. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-065. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_39() {
  echo "SRV-066. DNS Zone Transfer 설정  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-066. DNS Zone Transfer 설정 " >> $CREATE_FILE 2>&1
  echo ":: DNS 서비스 미사용 또는, Zone Transfer를 허가된 사용자에게만 허용한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "① DNS 서비스 활성화 여부 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  	if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
      then
        echo "DNS 서비스가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
      else
       echo "DNS 서비스가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
	fi

  echo " " >> $CREATE_FILE 2>&1

  ls -al /etc/rc*.d/* | grep -i named | grep "/S" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1

  echo "② /etc/named.conf 파일의 allow-transfer 확인" >> $CREATE_FILE 2>&1
    if [ -f /etc/named.conf ]
      then
        cat /etc/named.conf | grep 'allow-transfer' >> $CREATE_FILE 2>&1
      else
        echo "/etc/named.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
   fi

  echo " " >> $CREATE_FILE 2>&1

  echo "③ /etc/named.boot 파일의 xfrnets 확인" >> $CREATE_FILE 2>&1
    if [ -f /etc/named.boot ]
      then
        cat /etc/named.boot | grep "\xfrnets" >> $CREATE_FILE 2>&1
      else
        echo "/etc/named.boot 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
    fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ `cat dnsenable.txt | grep "DNSENABLE" | wc -l` -eq 0 ]
    then
      echo "★ SRV-066. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      if [ -f /etc/named.conf ]
        then
          if [ `cat /etc/named.conf | grep "\allow-transfer.*[0-256].[0-256].[0-256].[0-256].*" | grep -v "^#" | wc -l` -eq 0 ]
            then
              echo "★ SRV-066. 결과 : 취약" >> $CREATE_FILE 2>&1
            else
              echo "★ SRV-066. 결과 : 양호" >> $CREATE_FILE 2>&1
          fi
        else
          if [ -f /etc/named.boot ]
            then
              if [ `cat /etc/named.boot | grep "\xfrnets.*[0-256].[0-256].[0-256].[0-256].*" | grep -v "^#" | wc -l` -eq 0 ]
                then
                  echo "★ SRV-066. 결과 : 취약" >> $CREATE_FILE 2>&1
                else
                  echo "★ SRV-066. 결과 : 양호" >> $CREATE_FILE 2>&1
              fi
           else
              echo "★ SRV-066. 결과 : 수동진단" >> $CREATE_FILE 2>&1
          fi
      fi
  fi
  
  rm -rf dnsenable.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}



U_40() {
	echo -n "SRV-070. 비밀번호 저장파일 보호 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-070. 비밀번호 저장파일 보호" >> $CREATE_FILE 2>&1
	echo ":: 쉐도우 패스워드를 사용하거나, 패스워드를 암호화하여 저장하는 경우 양호" >> $CREATE_FILE 2>&1
	echo " PS: 정상, NP: 패스워드 없음 , LK:Lock 상태거나 NP 상태 " >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	cat /etc/passwd | grep -v "\*" | grep -v nologin | grep -v false | awk -F: '{print $1}' > PW.txt

	for P in `cat PW.txt`
	do
		passwd -S $P >> sd.txt
	done

	for W in `cat PW.txt`
	do
		cat /etc/shadow | grep -v '*' |grep -w $W >> d2.txt
	done

	echo "활성화 계정 /etc/shadow 패스워드 현황" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	cat d2.txt >> $CREATE_FILE 2>&1

	echo "" >> $CREATE_FILE 2>&1
	echo "활성화 계정 패스워드 상태" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	cat sd.txt >> $CREATE_FILE 2>&1

	echo "" >> $CREATE_FILE 2>&1

	if [ `awk -F" " '{print $2}' sd.txt | grep -i "np" | wc -l` -eq 0 ]
	then
		echo "★ SRV-070. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-070. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	rm -rf PW.txt sd.txt d2.txt

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_41() {
	echo -n "SRV-073. 관리자 그룹에 최소한의 사용자 포함 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-073. 관리자 그룹에 최소한의 사용자 포함" >> $CREATE_FILE 2>&1
	echo ":: 관리자 그룹에 불필요한 계정이 등록되어 있지 않은 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/group ]
	then
		echo "☞ 관리자 그룹 계정 현황" >> $CREATE_FILE 2>&1
		cat /etc/group | grep "root:" >> $CREATE_FILE 2>&1
	else
		echo " /etc/group 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	cat /etc/group | grep "root:" | awk -F: '$4!=null { print $4 }' > group.txt 2>&1

	if [ `cat group.txt | wc -l` -ne 0 ]
	then
		if [ `cat group.txt | awk -F, '{for (i=1;i<=NF;i++) {if($i!="root") print $i}}' | wc -l ` -eq 0 ]
		then
			echo "★ SRV-073. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-073. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	else
		echo "★ SRV-073. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi

	rm -rf group.txt

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_42() {
  echo -n "SRV-081. Crontab 설정파일 권한 설정 오류  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-081. Crontab 설정파일 권한 설정 오류 " >> $CREATE_FILE 2>&1
  echo ":: Crontab 작업 설정 파일들의 Group 권한에 쓰기 권한이 없고 Other 권한에 읽기.쓰기 권한이 없는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  cronfile="/var/spool/cron /etc/cron.daily /etc/cron.hourly /etc/cron.monthly /etc/cron.weekly"
  
  for cfile in $cronfile
	do
	ls -alL $cfile* | grep "^-" >> cronfile.txt 2>&1
	done
	cat cronfile.txt >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat cronfile.txt | grep "^-" | wc -l` -eq `cat cronfile.txt | grep "^-" | grep '.....-.---' | wc -l` ]
		then
			echo "GOOD" >> srv094.txt 2>&1
		else
			echo "BAD" >> srv094.txt 2>&1
			echo "해당 파일의 권한이 750 이상 입니다" >> $CREATE_FILE 2>&1
			cat cronfile.txt | grep "^-" | grep -v '.....-.---' >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat srv094.txt | grep "BAD" | wc -l` -eq 0 ]
		then
			echo "★ SRV-081. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-081. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi
	
	rm -f srv094.txt
	rm -f cronfile.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_43() {
  echo -n "SRV-082. 시스템 디렉토리 권한설정 미비  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-082. 시스템 디렉토리 권한설정 미비 " >> $CREATE_FILE 2>&1
  echo ":: 시스템 디렉토리들의 권한이 755이하로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  dirs="/sbin /etc /bin /usr/bin /usr/sbin /var"
  
  for dir in $dirs
	do
		ls -ald $dir >> $CREATE_FILE 2>&1
		ls -ald $dir >> dirfile.txt 2>&1
	done
	
	if [ `cat dirfile.txt | grep "^d" | wc -l` -eq `cat dirfile.txt | grep "^d" | grep '.....-..-.' | wc -l` ]
		then
			echo "GOOD" >> srv082.txt 2>&1
		else
			echo "BAD" >> srv082.txt 2>&1
			echo "해당 디렉토리의 권한이 755 이상 입니다" >> $CREATE_FILE 2>&1
			echo `cat dirfile.txt | grep "^d" | grep -v '.....-..-.'` >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat srv082.txt | grep "BAD" | wc -l` -eq 0 ]
		then
			echo "★ SRV-082. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-082. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	rm -f srv082.txt
	rm -f dirfile.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_44() {
  echo -n "SRV-083. 시스템 스타트업 스크립트 권한 설정 오류  >>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-083. 시스템 스타트업 스크립트 권한 설정 오류 " >> $CREATE_FILE 2>&1
  echo ":: 시스템 스타트업 스크립트 파일들의 권한이 755이하로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  ls -alL /etc/rc.d/* >> $CREATE_FILE 2>&1
  
  if [ `ls -alL /etc/rc.d/* | grep "^-" | wc -l` -eq `ls -alL /etc/rc.d/* | grep "^-" | grep '.....-..-.' | wc -l` ]
	then
		echo "GOOD" >> srv083.txt 2>&1
	else
		echo "BAD" >> srv083.txt 2>&1
		echo "해당 파일의 권한이 755 이상 입니다" >> $CREATE_FILE 2>&1
		echo `ls -alL /etc/rc.d/* | grep "^-" | grep -v '.....-..-.'` >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  
  if [ `cat srv083.txt | grep "BAD" | wc -l` -eq 0 ]
	then
		echo "★ SRV-083. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-083. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi
  
	rm -f srv083.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_45() {
	echo -n "SRV-084. /etc/passwd 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-084. /etc/passwd 파일 소유자 및 권한 설정"										>> $CREATE_FILE 2>&1
	echo ":: /etc/passwd 파일의 소유자가 root이고, 권한이 ,644 이하인 경우 양호"			>> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1


	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/passwd ]
	then
		ls -alL /etc/passwd >> $CREATE_FILE 2>&1
	else
		echo " /etc/passwd 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1


	if [ `ls -alL /etc/passwd | grep "...-.--.--" | wc -l` -eq 1 ]
	then
		echo "★ SRV-084. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-084. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_46() {
	echo -n "SRV-085. /etc/shadow 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-085. /etc/shadow 파일 소유자 및 권한 설정"										>> $CREATE_FILE 2>&1
	echo ":: /etc/shadow 파일의 소유자가 root이고, 권한이 400인 경우 양호"				>> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1


	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1


	if [ -f /etc/shadow ]
	then
		ls -alL /etc/shadow >> $CREATE_FILE 2>&1
	else
		echo " /etc/shadow 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1


	if [ `ls -alL /etc/shadow | grep "..--------" | wc -l` -eq 1 ]
	then
		echo "★ SRV-085. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-085. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_47() {
	echo -n "SRV-086. /etc/hosts 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-086. /etc/hosts 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
	echo ":: /etc/hosts 파일의 소유자가 root이고, 권한이 644인 경우 양호" >> $CREATE_FILE 2>&1  
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	if [ -f /etc/hosts ]
	then
		echo "/etc/hosts 파일 퍼미션" >> $CREATE_FILE 2>&1
		ls -alL /etc/hosts >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "/etc/hosts 파일 내용" >> $CREATE_FILE 2>&1
		cat /etc/hosts | grep -v "^#" >> $CREATE_FILE 2>&1
	else
		echo " /etc/hosts 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1


	if [ `ls -alL /etc/hosts | grep "...-.--.--" | wc -l` -eq 1 ]
	then
		if [ `ls -al /etc/hosts | awk '{print $3}' | grep -i "root" | wc -l` -eq 1 ]
		then
			echo "★ SRV-086. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-086. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	else
		echo "★ SRV-086. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_48() {
  echo "SRV-087. C 컴파일러 존재 및 권한 설정 오류  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-087. C 컴파일러 존재 및 권한 설정 오류 " >> $CREATE_FILE 2>&1
  echo ":: 불필요한 C컴파일러가 존재하지 않을 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  gcc --version >> gccv.txt 2>&1
  if [ `cat gccv.txt | wc -l` -gt 1 ]
	then
		gcc --version >> $CREATE_FILE 2>&1
		gwhich=`which gcc`
		if [ `ls -alL $gwhich | grep '.....-.---' | wc -l` -ge 1 ]
			then
				ls -alL $gwhich >> $CREATE_FILE 2>&1
				echo "적적한 권한을 사용하고 있습니다 750 이상" >> $CREATE_FILE 2>&1
				echo "적절한 사용 여부 확인 필요. (인터뷰/수동진단)" >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
				echo "★ SRV-087. 결과 : 수동진단" >> $CREATE_FILE 2>&1
			else
				ls -alL $gwhich >> $CREATE_FILE 2>&1
				echo "부적절한 권한을 사용하고 있습니다." >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
				echo "★ SRV-087. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	else
		echo "gcc 존재 하지 않음" >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "★ SRV-087. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

    rm -rf gccv.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_49() {
	echo -n "SRV-088. /etc/(x)inetd.conf 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-088. /etc/(x)inetd.conf 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
	echo ":: /etc/(X)inetd.conf파일의 소유자가 root이고, 권한이 600인 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -d /etc/xinetd.d ] 
	then
		echo "☞ /etc/xinetd.d 디렉토리 내용 현황." >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.d/* >> $CREATE_FILE 2>&1
	else
		echo "/etc/xinetd.d 디렉토리가 없습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/xinetd.conf ]
	then
		echo "☞ /etc/xinetd.conf 파일 퍼미션 현황." >> $CREATE_FILE 2>&1
		ls -al /etc/xinetd.conf >> $CREATE_FILE 2>&1
	else
		echo "/etc/xinetd.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	if [ -f /etc/inetd.conf ]
	then
		echo "☞ /etc/inetd.conf 파일 퍼미션 현황." >> $CREATE_FILE 2>&1
		ls -al /etc/inetd.conf >> $CREATE_FILE 2>&1
	else
		echo "/etc/inetd.conf 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	echo " " > inetd.txt

	if [ -f /etc/inetd.conf ]
	then
		if [ `ls -alL /etc/inetd.conf | awk '{print $1}' | grep '...-------'| wc -l` -eq 1 ]
		then
			echo "GOOD" >> inetd.txt
		else
			echo "BAD" >> inetd.txt
		fi
	else
		echo "GOOD" >> inetd.txt
	fi

	if [ -f /etc/xinetd.conf ]
	then
		if [ `ls -alL /etc/xinetd.conf | awk '{print $1}' | grep '...-------'| wc -l` -eq 1 ]
		then
			echo "GOOD" >> inetd.txt
		else
			echo "BAD" >> inetd.txt
		fi
	else
		echo "" >> inetd.txt
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	if [ -d /etc/xinetd.d ]
	then
		if [ `ls -alL /etc/xinetd.d/* | awk '{print $1}' | grep -v '...-------'| wc -l` -gt 0 ]
		then
			echo "BAD" >> inetd.txt
		else
			echo "GOOD" >> inetd.txt
		fi
	else
		echo "GOOD" >> inetd.txt
	fi

	if [ `cat inetd.txt | grep "BAD" | wc -l` -eq 0 ]
	then
		echo "★ SRV-088. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-088. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	rm -rf inetd.txt


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_50() {
	echo -n "SRV-089. /etc/syslog.conf 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-089. /etc/syslog.conf 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
	echo ":: /etc/syslog.conf 파일의 소유자가 root이고, 권한이 644인 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1


	if [ -f  /etc/rsyslog.conf ]
	then
		echo "☞ rsyslog 파일권한" >> $CREATE_FILE 2>&1
		ls -alL /etc/rsyslog.conf  >> $CREATE_FILE 2>&1
	elif [ -f /etc/syslog.conf ]
	then
		echo "☞ syslog 파일권한" >> $CREATE_FILE 2>&1
		ls -alL /etc/syslog.conf  >> $CREATE_FILE 2>&1
	else 
		echo "☞ syslog-ng 파일권한" >> $CREATE_FILE 2>&1
		ls -alL /etc/syslog-ng.conf  >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	if [ -f /etc/syslog.conf ]
	then
		if [ `ls -alL /etc/syslog.conf | awk '{print $1}' | grep '...-.--.--' | wc -l` -eq 1 ]
		then
			echo "GOOD" >> syslog.txt 2>&1
		else
			echo "BAD" >> syslog.txt 2>&1
		fi
	elif [ -f /etc/rsyslog.conf ]
	then 
		if [ `ls -alL /etc/rsyslog.conf | awk '{print $1}' | grep '...-.--.--' | wc -l` -eq 1 ]
		then
			echo "GOOD" >> syslog.txt 2>&1
		else
			echo "BAD" >> syslog.txt 2>&1
		fi
	fi
	
	if [ -f /etc/syslog-ng.conf ]
	then
		if [ `ls -alL /etc/syslog-ng.conf | awk '{print $1}' | grep '...-.--.--' | wc -l` -eq 1 ]
		then
			echo "GOOD" >> syslog.txt 2>&1
		else
			echo "BAD" >> syslog.txt 2>&1
		fi
	fi 

	if [ `cat syslog.txt | grep "BAD" | wc -l` -eq 0 ]
	then
		echo "★ SRV-089. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-089. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_51() {
	echo -n "SRV-091. SUID, SGID, Sticky bit 설정 파일 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-091. SUID, SGID, Sticky bit 설정 파일 점검 " >> $CREATE_FILE 2>&1
	echo ":: 주요 파일의 권한에 SUID와 SGID에 대한 설정이 부여되어 있지 않을 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	FILES="/sbin/dump /usr/bin/lpq-lpd /usr/bin/newgrp /sbin/restore /usr/bin/lpr /usr/sbin/lpc /sbin/unix_chkpwd /usr/bin/lpr-lpd /usr/sbin/lpc-lpd /usr/bin/at /usr/bin/lprm /usr/sbin/traceroute /usr/bin/lpq /usr/bin/lprm-lpd"

	for check_file in $FILES
	do
		if [ -f $check_file ]
		then
			if [ -g $check_file -o -u $check_file -o -k $check_file ]
			then
				echo `ls -alL $check_file` >> $CREATE_FILE 2>&1
			else
				echo $check_file "파일에 SUID, SGID, Sticky bit가 부여되어 있지 않습니다." >> $CREATE_FILE 2>&1
			fi
		else
			echo $check_file "이 없습니다." >> $CREATE_FILE 2>&1
		fi
	done

	echo " " >> $CREATE_FILE 2>&1


	echo " " > set.txt

	FILES="/sbin/dump /usr/bin/lpq-lpd /usr/bin/newgrp /sbin/restore /usr/bin/lpr /usr/sbin/lpc /sbin/unix_chkpwd /usr/bin/lpr-lpd /usr/sbin/lpc-lpd /usr/bin/at /usr/bin/lprm /usr/sbin/traceroute /usr/bin/lpq /usr/bin/lprm-lpd"

	for check_file in $FILES
	do
		if [ -f $check_file ]
		then
			if [ `ls -alL $check_file | awk '{print $1}' | egrep -i 's|t'| wc -l` -gt 0 ]
			then
				ls -alL $check_file |awk '{print $1}' | grep -i 's' >> set.txt
			else
				echo " " >> set.txt
			fi
		fi
	done

	if [ `cat set.txt | awk '{print $1}' | egrep -i 's|t' | wc -l` -ge 1 ]
	then
		echo "★ SRV-091. 결과 : 취약" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-091. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi

	rm -rf set.txt


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_52() {
  echo -n "SRV-092. 홈디렉토리 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-092. 홈디렉토리 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: 홈 디렉터리 소유자가 해당 계정이고, 일반 사용자 쓰기 권한이 제거된 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  HOMEDIRS=`cat /etc/passwd | egrep -v "false|nologin"  | awk -F":" 'length($6) > 0 {print $6}' | sort -u | grep -v "^#" | grep -v "/tmp" | grep -v "uucppublic" | grep -v "var" | grep -v "news" | uniq`
  
  for dir in $HOMEDIRS
    do
      if [ -d $dir ]; then
  	    ls -dal $dir | grep '\d.........' >> homedir.txt 2>&1
		fi
    done
  echo " " >> $CREATE_FILE 2>&1
	if [ `cat homedir.txt | grep "........w." | wc -l` -ge 1 ]
		then
			
			cat homedir.txt | grep "........w." >> $CREATE_FILE 2>&1
	else 
		echo "홈 디렉터리 소유자 및 권한 설정이 양호 합니다." >> $CREATE_FILE 2>&1
		
		cat homedir.txt >> $CREATE_FILE 2>&1
	fi
		
  echo " " > home.txt
  HOMEDIRS=`cat /etc/passwd | egrep -v "false|nologin" | awk -F":" 'length($6) > 0 {print $6}' | sort -u | grep -v "^#" | grep -v "/tmp" | grep -v "uucppublic" | grep -v "var" | grep -v "news" | uniq`
  for dir in $HOMEDIRS
    do
      if [ -d $dir ]
        then
          if [ `ls -dal $dir |  awk '{print $1}' | grep "........w." | grep '\d.........'| wc -l` -ge 1 ]
            then
              echo "BAD" >> home.txt
            else
              echo "GOOD" >> home.txt
          fi
        else
          echo "GOOD" >> home.txt
      fi
    done

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat home.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-092. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-092. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf home.txt homedir.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_53() {
  echo -n "SRV-093. world writable 파일 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-093. world writable 파일 점검 " >> $CREATE_FILE 2>&1
  echo ":: world writable 파일 존재 여부를 확인하고, 존재 시 설정이유를 확인하고 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  HOMEDIR=`cat /etc/passwd | egrep -v ":nosh" | grep "sh$" | awk -F":" '{print $6}' | sort -u`
    
  find /tmp -perm -2 -ls | grep -v "srw.rw.rw." | grep -v " lrw.rw.rw." | grep -v "rwt" | awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l > world.txt 2>&1
  find /home -perm -2 -ls | grep -v "srw.rw.rw." | grep -v "p.w..w..w." | grep -v " lrw.rw.rw." |awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l >> world.txt 2>&1
  find /var -perm -2 -ls | grep -v "srw.rw.rw." | grep -v "p.w..w..w." | grep -v " lrw.rw.rw." | grep -v "tmp" | grep -v "dev" | awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l >> world.txt 2>&1
  find /bin -perm -2 -ls | grep -v "srw.rw.rw."| grep -v "p.w..w..w." | grep -v " lrw.rw.rw."  |awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l >> world.txt 2>&1 
  find /sbin -perm -2 -ls | grep -v "srw.rw.rw."| grep -v "p.w..w..w." | grep -v " lrw.rw.rw." |awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l >> world.txt 2>&1
  find $HOMEDIR -perm -2 -ls | grep -v "srw.rw.rw."| grep -v "p.w..w..w." | grep -v " lrw.rw.rw." |awk '{print $3 " : " $5 " : " $6 " : " $11}' | grep -v ^l >> world.txt 2>&1
  
  if [ -s world.txt ]
    then
	  cat world.txt  >> $CREATE_FILE 2>&1
      echo " " >> $CREATE_FILE 2>&1		
	  echo "★ SRV-093. 결과 : 취약" >> $CREATE_FILE 2>&1
	
    else
	  echo "☞ World Writable 권한이 부여된 파일이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
	  echo " " >> $CREATE_FILE 2>&1
      echo "★ SRV-093. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf world.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_54() {
  echo -n "SRV-094. Crontab 참조파일 권한 설정 오류  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-094. Crontab 참조파일 권한 설정 오류 " >> $CREATE_FILE 2>&1
  echo ":: Crontab 작업 설정 파일들의 Group,Other 권한에 쓰기 권한이 없는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  cronfile="/var/spool/cron /etc/cron.daily /etc/cron.hourly /etc/cron.monthly /etc/cron.weekly"
  
  for cfile in $cronfile
	do
	ls -alL $cfile* | grep "^-" >> cronfile.txt 2>&1
	done
	cat cronfile.txt >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat cronfile.txt | grep "^-" | wc -l` -eq `cat cronfile.txt | grep "^-" | grep '.....-..-.' | wc -l` ]
		then
			echo "GOOD" >> srv094.txt 2>&1
		else
			echo "BAD" >> srv094.txt 2>&1
			echo "해당 파일에 Group,Other 쓰기 권한이 있습니다." >> $CREATE_FILE 2>&1
			cat cronfile.txt | grep "^-" | grep -v '.....-..-.' >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
	if [ `cat srv094.txt | grep "BAD" | wc -l` -eq 0 ]
		then
			echo "★ SRV-094. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-094. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi
	
	rm -f srv094.txt
	rm -f cronfile.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_55() {
	echo -n "SRV-095. 파일 및 디렉토리 소유자 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-095. 파일 및 디렉토리 소유자 설정" >> $CREATE_FILE 2>&1
	echo ":: 소유자가 존재하지 않은 파일 및 디렉터리가 존재하지 않은 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	echo "☞ 소유자가 존재하지 않는 파일 (소유자 => 파일위치: 경로)" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

	find /tmp -ls 2> /dev/null  | awk '{print $5 " => 파일위치:" $11}' | egrep -v -i '(^a|^b|^c|^d|^e|^f|^g|^h|^i|^j|^k|^l|^m|^n|^o|^p|^q|^r|^s|^t|^u|^v|^w|^x|^y|^z|^_)' > file-own.txt
	find /home -ls 2> /dev/null  | awk '{print $5 " => 파일위치:" $11}' | egrep -v -i '(^a|^b|^c|^d|^e|^f|^g|^h|^i|^j|^k|^l|^m|^n|^o|^p|^q|^r|^s|^t|^u|^v|^w|^x|^y|^z|^_)' >> file-own.txt
	find /var -ls 2> /dev/null  | awk '{print $5 " => 파일위치:" $11}' | egrep -v -i '(^a|^b|^c|^d|^e|^f|^g|^h|^i|^j|^k|^l|^m|^n|^o|^p|^q|^r|^s|^t|^u|^v|^w|^x|^y|^z|^_)' >> file-own.txt
	find /bin -ls 2> /dev/null | awk '{print $5 " => 파일위치:" $11}' | egrep -v -i '(^a|^b|^c|^d|^e|^f|^g|^h|^i|^j|^k|^l|^m|^n|^o|^p|^q|^r|^s|^t|^u|^v|^w|^x|^y|^z|^_)' >> file-own.txt
	find /sbin -ls 2> /dev/null | awk '{print $5 " => 파일위치:" $11}' | egrep -v -i '(^a|^b|^c|^d|^e|^f|^g|^h|^i|^j|^k|^l|^m|^n|^o|^p|^q|^r|^s|^t|^u|^v|^w|^x|^y|^z|^_)' >> file-own.txt


	if [ -s file-own.txt ]
	then
		cat file-own.txt >> $CREATE_FILE 2>&1
	else
		echo "소유자가 존재하지 않는 파일이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	if [ -s file-own.txt ]
	then
		echo "★ SRV-095. 결과 : 취약" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-095. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi

	rm -rf file-own.txt


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_56() {
  echo -n "SRV-096. 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정 >>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-096. 사용자, 시스템 시작파일 및 환경파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: 홈 디렉터리 환경변수 파일 소유자가 root 또는, 해당 계정으로 지정되어 있고," >> $CREATE_FILE 2>&1
  echo "   홈 디렉터리 환경변수 파일에 root와 소유자만 쓰기 권한이 부여되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u | grep -v '/bin/false' | grep -v 'nologin' | grep -v "^#"`
  FILES=".profile .cshrc .kshrc .login .bash_profile .bashrc .bash_login .exrc .netrc .history .sh_history .bash_history .dtprofile"

  for file in $FILES
  do
    FILE=/$file
    if [ -f $FILE ]
      then
        ls -al $FILE >> $CREATE_FILE 2>&1
    fi
  done

  for dir in $HOMEDIRS
  do
    for file in $FILES
    do
      FILE=$dir/$file
        if [ -f $FILE ]
          then
          ls -al $FILE >> $CREATE_FILE 2>&1
        fi
    done
  done
  echo " " >> $CREATE_FILE 2>&1

  echo " " > home.txt

  HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u | grep -v '/bin/false' | grep -v 'nologin' | grep -v "^#"`
  FILES=".profile .cshrc .kshrc .login .bash_profile .bashrc .bash_login .exrc .netrc .history .sh_history .bash_history .dtprofile"

  for file in $FILES
    do
      if [ -f /$file ]
        then
          if [ `ls -alL /$file |  awk '{print $1}' | grep "........-." | wc -l` -eq 0 ]
            then
              echo "BAD" >> home.txt
            else
              echo "GOOD" >> home.txt
          fi
        else
          echo "GOOD" >> home.txt
      fi
    done

  for dir in $HOMEDIRS
    do
      for file in $FILES
        do
          if [ -f $dir/$file ]
            then
              if [ `ls -al $dir/$file | awk '{print $1}' | grep "........-." | wc -l` -eq 0 ]
                then
                  echo "BAD" >> home.txt
                else
                  echo "GOOD" >> home.txt
              fi
            else
              echo "GOOD" >> home.txt
          fi
        done
    done

  if [ `cat home.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-096. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-096. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

  rm -rf home.txt


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_57() {
	echo -n "SRV-099. /etc/services 파일 소유자 및 권한 설정  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-099. /etc/services 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
	echo ":: /etc/services 파일의 소유자가 root이고, 권한이 644인 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -f  /etc/services ]
	then
		ls -alL /etc/services  >> $CREATE_FILE 2>&1
	else
		echo " /etc/services 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
		echo "★ SRV-099. 결과 : 수동진단" >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/services ]
	then
		if [ `ls -alL /etc/services | awk '{print $1}' | grep '...-.--.--' | wc -l` -eq 1 ]
		then
			echo "★ SRV-099. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-099. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_58() {
  echo -n "SRV-100. xterm 실행 파일 권한 설정  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-100. xterm 실행 파일 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: xterm 실행 파일의 권한이 600이하로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  find /usr /bin -perm -1 -type f -name xterm -ls >> srv100.txt
  if [ `cat srv100.txt | wc -l` -gt 0 ]
    then
      cat srv100.txt >> $CREATE_FILE 2>&1
    else
      echo " xterm 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ `cat srv100.txt | wc -l` -gt 0 ]
    then
      if [ `ls -alL $xtermfile | awk '{print $1}' | grep '...-------' | wc -l` -eq 1 ]
        then
          echo "★ SRV-100. 결과 : 양호" >> $CREATE_FILE 2>&1
        else
          echo "★ SRV-100. 결과 : 취약" >> $CREATE_FILE 2>&1
      fi
    else
      echo "★ SRV-100. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

        rm -rf srv100.txt
        echo " " >> $CREATE_FILE 2>&1
        echo " " >> $CREATE_FILE 2>&1
        echo "완료"
        echo " "
}

U_59() {
  echo -n "SRV-106. hosts.lpd 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-106. hosts.lpd 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: 파일의 소유자가 root이고 Other에 쓰기 권한이 부여되어 있지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ -f  /etc/hosts.lpd ]
    then
      ls -alL /etc/hosts.lpd  >> $CREATE_FILE 2>&1
    else
      echo " /etc/hosts.lpd 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/hosts.lpd ]
    then
      if [ `ls -alL /etc/hosts.lpd | awk '{print $1}' | grep '...-------' | wc -l` -eq 1 ]
        then
          echo "★ SRV-106. 결과 : 양호" >> $CREATE_FILE 2>&1
       else
          echo "★ SRV-106. 결과 : 취약" >> $CREATE_FILE 2>&1
      fi
    else
      echo "★ SRV-106. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_60() {
  echo -n "SRV-107. at 접근제한 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-107. at 접근제한 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: at 접근제어 파일의 소유자가 root이고, 권한이 640 이하인 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
   

  echo "① at.allow, at.deny 파일 정보" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/at.allow ] 
	then
	    ls -al /etc/at.allow >> $CREATE_FILE 2>&1
		if [ -f /etc/at.deny ]
			then
			    ls -al /etc/at.deny >> $CREATE_FILE 2>&1
				if [ \( `ls -l /etc/at.allow | awk '{print $3}' | grep -i root |wc -l` -eq 1 \) -a \( `ls -l /etc/at.allow | grep '...-.-----' | wc -l` -eq 1 \) ]; 
					then
						if [ \( `ls -l /etc/at.deny | awk '{print $3}' | grep -i root |wc -l` -eq 1 \) -a \( `ls -l /etc/at.deny | grep '...-.-----' | wc -l` -eq 1 \) ];
						  then
							echo "★ SRV-107. 결과 : 양호" >> $CREATE_FILE 2>&1
						  else
						    echo "★ SRV-107. 결과 : 취약" >> $CREATE_FILE 2>&1
						fi
					else
					  echo "★ SRV-107. 결과 : 취약" >> $CREATE_FILE 2>&1
                fi
             else
              if [ \( `ls -l /etc/at.allow | awk '{print $3}' | grep -i root |wc -l` -eq 1 \) -a \( `ls -l /etc/at.allow | grep '...-.-----' | wc -l` -eq 1 \) ]; 
				then
					echo "★ SRV-107. 결과 : 양호" >> $CREATE_FILE 2>&1
				else
				    echo "★ SRV-107. 결과 : 취약" >> $CREATE_FILE 2>&1
			  fi
		 fi
     else
	 echo "at.allow, at.deny 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	 echo " " >> $CREATE_FILE 2>&1
	 echo "★ SRV-107. 결과 : 취약" >> $CREATE_FILE 2>&1
fi

  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_61() {
  echo "SRV-108. 과도한 시스템 로그파일 권한 설정  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-108. 과도한 시스템 로그파일 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: 시스템 로그 파일의 권한이 644 이하인 경우 양호" >> $CREATE_FILE 2>&1
  echo ":: 시스템 로그 설정파일의 권한이 640 이하인 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "시스템 로그파일 리스트" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
 
  ls -al /etc | egrep "syslog.conf|rsyslog.conf" > sysfile1.txt 2>&1
  ls -al /var/log/* /var/adm/* | egrep "audit|secure|wtmp|utmp|btmp|syslog|sulog|pacct|auth|messages|loginlog" | grep "^-" >> sysfile2.txt 2>&1  
  echo " " >> $CREATE_FILE 2>&1

	if [ `cat sysfile1.txt | wc -l` -eq `cat sysfile1.txt | grep '...-.-----' | wc -l` ]
		then
			echo "GOOD" >> log.txt 2>&1
		else
			echo "BAD" >> log.txt 2>&1
			echo "해당 파일의 권한이 640 이상 입니다" >> $CREATE_FILE 2>&1
			echo `cat sysfile1.txt | grep -v '...-.-----'` >> $CREATE_FILE 2>&1
	fi
	
	if [ `cat sysfile2.txt | wc -l` -eq `cat sysfile2.txt | grep '...-.--.--' | wc -l` ]
		then
			echo "GOOD" >> log.txt 2>&1
		else
			echo "BAD" >> log.txt 2>&1
			echo "해당 파일의 권한이 644 이상 입니다" >> $CREATE_FILE 2>&1
			echo `cat sysfile2.txt | grep -v '...-.--.--'` >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1
	
    cat sysfile1.txt >> $CREATE_FILE 2>&1
    cat sysfile2.txt >> $CREATE_FILE 2>&1
    echo " " >> $CREATE_FILE 2>&1	
	if [ `cat log.txt | grep "BAD" | wc -l` -eq 0 ]
		then
			echo "★ SRV-108. 결과 : 양호" >> $CREATE_FILE 2>&1
		else
			echo "★ SRV-108. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi
	
	rm -f sysfile1.txt
	rm -f sysfile2.txt
	rm -f log.txt
	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_62() {
  echo -n "SRV-115. 로그의 정기적 검토 및 보고 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-115. 로그의 정기적 검토 및 보고 " >> $CREATE_FILE 2>&1
  echo ":: 로그 기록의 검토, 분석, 리포트 작성 및 보고 등이 정기적으로 이루어지는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "해당항목은 운영담당자와 인터뷰를 통해서 점검 진행" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "★ SRV-115. 결과 : 수동진단" >> $CREATE_FILE 2>&1

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_63() {
	echo -n "SRV-121. root 홈, 패스 디렉토리 권한 및 패스 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-121. root 홈, 패스 디렉토리 권한 및 패스 설정" >> $CREATE_FILE 2>&1
	echo ":: PATH 환경변수에 . 이 맨 앞이나 중간에 포함되지 않은 경우" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	echo " " >> $CREATE_FILE 2>&1
	echo $PATH >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	echo " " >> $CREATE_FILE 2>&1

	if [ `echo $PATH | grep "\.:" | wc -l` -eq 0 ]
	then
		echo "★ SRV-121. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-121. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_64() {
  echo -n "SRV-122. UMASK 설정 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-122. UMASK 설정 점검 " >> $CREATE_FILE 2>&1
  echo ":: UMASK 값이 022 이하로 설정된 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ UMASK 명령어  " >> $CREATE_FILE 2>&1
  umask >> $CREATE_FILE 2>&1

  echo "  " >> $CREATE_FILE 2>&1

  echo "☞ /etc/profile 파일  " >> $CREATE_FILE 2>&1
  if [ -f /etc/profile ]
    then
      cat /etc/profile  |grep -i -A1 -B1 umask | grep -v "^#" >> $CREATE_FILE 2>&1
      if [ `cat /etc/profile | grep -i "umask" | grep -v "^#" | awk -F"0" '$2 < "22"' | wc -l` -gt 0 ]
      then
        echo "BAD" > umask.txt
      else
        echo "GOOD" >> umask.txt
      fi
    else
      echo "/etc/profile 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi
  
  echo "  " >> $CREATE_FILE 2>&1
  
  echo "☞ /etc/bashrc 파일  " >> $CREATE_FILE 2>&1
  if [ -f /etc/bashrc ]
    then
      cat /etc/bashrc | grep -v "^#"| grep -i umask >> $CREATE_FILE 2>&1
    else
      echo "/etc/bashrc 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo "  " >> $CREATE_FILE 2>&1
  
   echo "☞ /etc/csh.cshrc 파일  " >> $CREATE_FILE 2>&1
  if [ -f /etc/csh.cshrc ]
    then
      cat /etc/csh.cshrc | grep -v "^#"| grep -i umask >> $CREATE_FILE 2>&1
    else
      echo "/etc/csh.cshrc 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  fi

  echo "  " >> $CREATE_FILE 2>&1 
  

 if [ `cat umask.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-122. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-122. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

 rm -rf umask.txt
 
 
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}


U_65() {
	echo -n "SRV-131. SU 명령 사용가능 그룹 제한 미비 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-131. SU 명령 사용가능 그룹 제한 미비" >> $CREATE_FILE 2>&1
	echo ":: su 명령어를 특정 그룹에 속한 사용자만 사용하도록 제한되어 있는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/pam.d/su ]
	then
		echo "① /etc/pam.d/su 파일" >> $CREATE_FILE 2>&1
		cat /etc/pam.d/su | grep 'pam_wheel.so' | grep -v 'trust' >> $CREATE_FILE 2>&1
	else
		echo "/etc/pam.d/su 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1

	echo "② /bin/su 파일" >> $CREATE_FILE 2>&1
	if [ -f /bin/su ]
	then
	  ls -al /bin/su >> $CREATE_FILE 2>&1
	else
	  echo "/bin/su 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1

	echo "③ /usr/bin/su 파일" >> $CREATE_FILE 2>&1
	if [ -f /usr/bin/su ]
	then
	  ls -al /usr/bin/su >> $CREATE_FILE 2>&1
	else
	  echo "/usr/bin/su 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1	
	fi

	echo " " >> $CREATE_FILE 2>&1

	echo "④ /etc/group 파일" >> $CREATE_FILE 2>&1
	cat /etc/group >> $CREATE_FILE 2>&1

	echo " " >> $CREATE_FILE 2>&1

	if [ `cat /etc/pam.d/su | grep 'pam_wheel.so' | grep -v '^#' | grep -v 'trust' | wc -l` -ge 1 ]
	then
		if [ -f /bin/su ]
		then
			if [ `ls -alL /bin/su | grep ".....-.---" | wc -l` -eq 1 ]
			then
				if [ `ls -alL /bin/su | awk '{print $4}' | grep "root" | wc -l` -eq 0 ]
				then
					echo "★ SRV-131. 결과 : 양호" >> $CREATE_FILE 2>&1
				else
					echo "★ SRV-131. 결과 : 취약" >> $CREATE_FILE 2>&1
				fi	
			else
				echo "★ SRV-131. 결과 : 취약" >> $CREATE_FILE 2>&1
			fi
		else
			echo "★ SRV-131. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	else
		echo "★ SRV-131. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_66() {
  echo -n "SRV-132. cron 파일 소유자 및 권한 설정  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-132. cron 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: cron 접근제어 파일 소유자가 root이고, 권한이 640 이하인 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "① Cron.allow 파일 정보" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/cron.allow ]
    then
        if [ \( `ls -l /etc/cron.allow | awk '{print $3}' | grep -i root |wc -l` -eq 1 \) -a \( `ls -l /etc/cron.allow | grep '...-.-----' | wc -l` -eq 1 \) ]; 
            then 
                echo "GOOD" >> srv-132.txt
                ls -alL /etc/cron.allow  >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
            else
                echo "BAD" >> srv-132.txt
                ls -alL /etc/cron.allow  >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
		fi
    else
      echo " /etc/cron.allow 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
	  echo " " >> $CREATE_FILE 2>&1
  fi

  echo "② Cron.deny 파일 정보" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/cron.deny ]
    then
        if [ \( `ls -l /etc/cron.deny | awk '{print $3}' | grep -i root |wc -l` -eq 1 \) -a \( `ls -l /etc/cron.deny | grep '...-.-----' | wc -l` -eq 1 \) ];
            then
                echo "GOOD" >> srv-132.txt
                ls -alL /etc/cron.deny  >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
            else
                echo "BAD" >> srv-132.txt
                ls -alL /etc/cron.deny  >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
		fi
    else
      echo " /etc/cron.deny 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
	  echo " " >> $CREATE_FILE 2>&1
  fi

 if [ `cat srv-132.txt | grep "BAD" | wc -l` -gt 0 ]
    then
	  echo " " >> $CREATE_FILE 2>&1
	  echo "★ SRV-132. 결과 : 취약" >> $CREATE_FILE 2>&1
    else 
      echo " " >> $CREATE_FILE 2>&1
	  echo "★ SRV-132. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf srv-132.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_67() {
  echo -n "SRV-133. cron 파일 내 계정 미존재  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-133. cron 파일 내 계정 미존재 " >> $CREATE_FILE 2>&1
  echo ":: cron.deny 파일 존재하지만 해당 파일에 계정 존재하지 않는 경우 취약 그외 모두 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "① Cron.allow 파일 내용 정보" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/cron.allow ]
    then
	  if [ -s /etc/cron.allow ]
		then
			cat /etc/cron.allow >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
		else
			echo "파일 내 계정이 등록되어 있지 않습니다." >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
	  fi
	  
	else
      echo " /etc/cron.allow 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
      echo " " >> $CREATE_FILE 2>&1
  fi

  echo "② Cron.deny 파일 내용 정보" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/cron.deny ]
    then
      if [ -s /etc/cron.deny ]
        then
          cat /etc/cron.deny >> $CREATE_FILE 2>&1
          echo " " >> $CREATE_FILE 2>&1
          echo "★ SRV-133. 결과 : 수동진단" >> $CREATE_FILE 2>&1
        else
          echo "파일 내 계정이 등록되어 있지 않습니다." >> $CREATE_FILE 2>&1
          echo " " >> $CREATE_FILE 2>&1
          echo "★ SRV-133. 결과 : 취약" >> $CREATE_FILE 2>&1		  
      fi

    else
      echo " /etc/cron.deny 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
      echo " " >> $CREATE_FILE 2>&1
	  echo "★ SRV-133. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi	
 
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_68() {
	echo -n "SRV-142. root 계정과 동일한 UID 금지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-142. root 계정과 동일한 UID 금지" >> $CREATE_FILE 2>&1
	echo ":: root 계정과 동일한 UID를 갖는 계정이 존재하지 않는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ -f /etc/passwd ]
	then
		awk -F: '$3==0 { print $1 " -> UID=" $3 }' /etc/passwd >> $CREATE_FILE 2>&1
	else
		echo "/etc/passwd 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1 
	fi

	echo " " >> $CREATE_FILE 2>&1

	echo "☞ /etc/passwd 파일 내용" >> $CREATE_FILE 2>&1
	cat /etc/passwd >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1

	if [ `awk -F: '$3==0  { print $1 }' /etc/passwd | grep -v "root" | wc -l` -eq 0 ]
	then
		echo "★ SRV-142. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-142. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_69() {
	echo -n "SRV-143. 일반 계정과 동일한 UID 금지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-143. 일반 계정과 동일한 UID 금지" >> $CREATE_FILE 2>&1
	echo ":: 동일한 UID로 설정된 사용자 계정이 존재하지 않는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	
	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	for uid in `cat /etc/passwd | awk -F: '{print $3}'`
	do
		cat /etc/passwd | awk -F: '$3=="'${uid}'" { print "UID=" $3 " -> " $1 }' > account.txt
	    if [ `cat account.txt | wc -l` -gt 1 ]
		then
			cat account.txt >> total-account.txt
		fi
	done

   if [ -f total-account.txt ]
   then
	if [ `sort -k 1 total-account.txt | wc -l` -gt 1 ]
		then
		    echo "동일한 UID를 사용하는 계정이 발견되었습니다." >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			sort -k 1 total-account.txt | uniq -d >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			echo "★ SRV-143. 결과 : 취약" >> $CREATE_FILE 2>&1
		else
			echo "동일한 UID를 사용하는 계정이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			echo "★ SRV-143. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi
  else
  	echo "동일한 UID를 사용하는 계정이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
    echo "★ SRV-143. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf account.txt
  rm -rf total-account.txt


	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_70() {
  echo -n "SRV-144. /dev에 존재하지 않는 device 파일 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-144. /dev에 존재하지 않는 device 파일 점검 " >> $CREATE_FILE 2>&1
  echo ":: dev에 대한 파일 점검 후 존재하지 않은 device 파일을 제거한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "① 기반시설 점검기준 명령 : find /dev -type f -exec ls -l {} \;" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1 
  find /dev -type f -exec ls -l {} \; > dev-file.txt

  if [ -s dev-file.txt ]
    then
	  cat dev-file.txt >> $CREATE_FILE 2>&1
    else
  	  echo "☞ /dev 에 존재하지 않은 Device 파일이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "디바이스 파일(charactor, block file) 점검 : find /dev -type [C B] -exec ls -l {} \;  " >> $CREATE_FILE 2>&1
  echo "major, minor 필드에 값이 올바르지 않은 경우 취약  " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1 
  find /dev -type c -exec ls -l {} \; >> dev-file2.txt
  find /dev -type b -exec ls -l {} \; >> dev-file2.txt
  
  if [ -s dev-file2.txt ]
    then
	  cat dev-file2.txt >> $CREATE_FILE 2>&1
    else
  	  echo "☞ /dev 에 charactor, block Device 파일이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -s dev-file.txt ]
    then
      echo "★ SRV-144. 결과 : 취약" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-144. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf dev-file.txt  dev-file2.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_71() {
  echo -n "SRV-145. 홈디렉토리로 지정한 디렉토리의 존재 관리 >>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-145. 홈디렉토리로 지정한 디렉토리의 존재 관리 " >> $CREATE_FILE 2>&1
  echo ":: 홈 디렉토리가 존재하지 않는 계정이 없고, " >> $CREATE_FILE 2>&1
  echo "   root 계정을 제외한 일반 계정의 홈 디렉터리가 '/'가 아닌 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ 홈 디렉터리가 존재하지 않는 계정리스트" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

  echo " " > DHOME_pan.txt
  
  HOMEDIRS=`cat /etc/passwd | egrep -v -i "nologin|false" | awk -F":" 'length($6) > 0 {print $6}' | sort -u | grep -v "^#" | grep -v "/tmp" | grep -v "uucppublic" | uniq`

  for dir in $HOMEDIRS
    do
	    if [ ! -d $dir ]
	      then
		      awk -F: '$6=="'${dir}'" { print "● 계정명(홈디렉터리):"$1 "(" $6 ")" }' /etc/passwd >> $CREATE_FILE 2>&1
		      echo " " > Home.txt
		 
	    fi
    done

  echo " " >> $CREATE_FILE 2>&1

  if [ ! -f Home.txt ]
    then
		  echo "홈 디렉터리가 존재하지 않은 계정이 발견되지 않았습니다." >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  echo "☞ root 계정 외 '/'를 홈디렉터리로 사용하는 계정리스트" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  
  if [ `cat /etc/passwd | egrep -v -i "nologin|false" | grep -v root | awk -F":" 'length($6) > 0' | awk -F":" '$6 == "/"' | wc -l` -eq 0 ]
  then
        echo "root 계정 외 '/'를 홈 디렉터리로 사용하는 계정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
  else
        cat /etc/passwd | egrep -v -i "nologin|false" | grep -v root | awk -F":" 'length($6) > 0' | awk -F":" '$6 == "/"' >> $CREATE_FILE 2>&1
        echo "BAD" >> DHOME_pan.txt
  fi
        

  echo " " >> $CREATE_FILE 2>&1

  if [ ! -f Home.txt ]
    then
      echo "GOOD" >> DHOME_pan.txt
    else
      echo "BAD" >> DHOME_pan.txt
      rm -rf Home.txt
  fi
  
  if [ `cat DHOME_pan.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-145. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-145. 결과 : 취약" >> $CREATE_FILE 2>&1
      
	  
  fi
  rm -rf DHOME_pan.txt
 rm -rf no_Home.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_72() {
  echo -n "SRV-146. ftp 계정 shell 제한 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-146. ftp 계정 shell 제한 " >> $CREATE_FILE 2>&1
  echo ":: ftp 계정에 /bin/false 쉘이 부여되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

   echo "① ftp 계정 쉘 확인(ftp 계정에 false 또는 nologin 설정시 양호)" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `cat /etc/passwd | awk -F: '$1=="ftp"' | egrep "false|nologin" | wc -l` -gt 0 ]
    then
      result61='good'
    else
      result61='Vulnerability'
  fi  
  
  if [ `cat /etc/passwd | awk -F: '$1=="ftp"' | wc -l` -gt 0 ]
    then
	    cat /etc/passwd | awk -F: '$1=="ftp"' >> $CREATE_FILE 2>&1
    else
	    echo "ftp 계정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
		result61='good'
  fi
  
  if [ $result61 = 'good' ]; then
	result61='양호'
  else
	result61='취약'
  fi
  
	 echo " " >> $CREATE_FILE 2>&1
  echo "★ SRV-146. 결과 : "$result61 >> $CREATE_FILE 2>&1


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_73() {
  echo -n "SRV-147. SNMP 서비스 구동 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-147. SNMP 서비스 구동 점검 " >> $CREATE_FILE 2>&1
  echo ":: SNMP 서비스를 사용하지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ SNMP 서비스 여부" >> $CREATE_FILE 2>&1
 
  echo " " >> $CREATE_FILE 2>&1
  
  if [ `cat snmpenable.txt | grep "SNMPDISABLE" | wc -l` -eq 1 ]
	then
		echo "SNMP가 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
	else
		echo "SNMP가 활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
    ls -al /etc/rc*.d/* | grep -i snmp | grep "/S" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1


  echo " " >> $CREATE_FILE 2>&1

  if [ `cat snmpenable.txt | grep "SNMPDISABLE" | wc -l` -eq 1 ]
    then
      echo "★ SRV-147. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-147. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi

rm -rf snmpenable.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_74() {
  echo -n "SRV-148. Apache 웹서비스 정보 숨김 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-148. Apache 웹서비스 정보 숨김 " >> $CREATE_FILE 2>&1
  echo ":: ServerTokens 지시자에 Prod 옵션이 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  
  if [ $web = 'default' ]; then
	echo '☞ Apache 서비스 비활성화되어 있습니다.' >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "★ SRV-148. 결과 : N/A" >> $CREATE_FILE 2>&1
  else
		if [ $path = 'ok' ]; then
			cat $conf | grep ServerTokens | grep -v "^#" >> Tokens.txt
			if [ `awk 'BEGIN {IGNORECASE=1} /ServerTokens/ {print $0}' "$conf" | grep -v '\#'|wc -l` -gt 0 ]; then
				echo "| $apache/conf/httpd.conf |" >> $CREATE_FILE
				awk 'BEGIN {IGNORECASE=1} /ServerTokens/ {print $0}' "$conf" | grep -v '\#' >> $CREATE_FILE
				if [ `awk 'BEGIN {IGNORECASE=1} /ServerTokens/ && /Prod/ || /Off/ {print $0}' Tokens.txt | wc -l` -gt 0 ]; then
					result_70='Good'
				else
					result_70='Vulnerability'
				fi
			else
				if [ `cat "$conf" |grep Include | grep -v '\#'| grep httpd-default.conf | wc -l` -eq 1 ]
					then
					echo "| "$apache"/conf/httpd.conf |" >> $CREATE_FILE
					if [ `cat "$apache"/extra/httpd-default.conf | grep ServerTokens | grep -v '\#' | awk -F' ' '{print $2}'` = 'Prod' ]
						then 
						echo ' ' >> $CREATE_FILE
						echo "| "$apache"/conf/extra/httpd-default.conf |" >> $CREATE_FILE
						cat "$apache"/extra/httpd-default.conf | grep ServerTokens|grep -v '\#' >> $CREATE_FILE
						result_70='Good'
					else
						echo ' ' >> $CREATE_FILE
						echo "| "$apache"/conf/extra/httpd-default.conf |" >> $CREATE_FILE
						cat "$conf"/extra/httpd-default.conf | grep ServerTokens| grep -v '\#' >> $CREATE_FILE
						result_70='Vulnerability'
					fi
				else
					result_70='Vulnerability'
					echo "| "$apache"/conf/httpd.conf |" >> $CREATE_FILE
					if [ \( `cat "$conf" | grep Include | grep httpd-default.conf | grep -v '\#' | wc -l` -eq 0 \) -a \( `cat "$conf" | grep ServerTokens | grep -v '\#' | wc -l` -eq 0 \) ]; then
						echo '해당 설정이 존재하지 않습니다.' >> $CREATE_FILE
					else
						if [ `cat "$conf" | grep Include | grep httpd-default.conf | grep -v '\#' | wc -l` -eq 0 ]; then
							cat "$conf" | grep ServerTokens >> $CREATE_FILE
						else
							cat "$conf" | grep Include | grep httpd-default.conf >> $CREATE_FILE
						fi
					fi
					echo ' ' >> $CREATE_FILE

					if [ ! -f "$apache"/extra/httpd-default.conf ]; then
						echo '해당 파일이 존재하지 않습니다.' >> $CREATE_FILE
					else
						cat "$apache"/extra/httpd-default.conf |grep ServerTokens >> $CREATE_FILE
					fi
				fi
			fi
		else
			result_70='interview'
			echo "ServerToken 설정 확인 -" $conf >> $CREATE_FILE 2>&1
			echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
			echo "conf 파일을 찾을 수 없습니다." >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
			echo ' ' >> $CREATE_FILE 2>&1
		fi		
		
		if [ -f $apache/conf.d/userdir.conf ]
			then
			cat $apache/conf.d/userdir.conf | grep ServerTokens | grep -v "^#" >> Tokens.txt
			if [ `awk 'BEGIN {IGNORECASE=1} /ServerTokens/ {print $0}' "$apache/conf.d/userdir.conf" | grep -v '\#'|wc -l` -gt 0 ]; then
				echo "| $apache/conf.d/userdir.conf |" >> $OUTFILE
				awk 'BEGIN {IGNORECASE=1} /ServerTokens/ {print $0}' "$apache/conf.d/userdir.conf" | grep -v '\#' >> $OUTFILE
				if [ `awk 'BEGIN {IGNORECASE=1} /ServerTokens/ && /Prod/ || /Off/ {print $0}' Tokens.txt | wc -l` -gt 0 ]; then
					result_70='Good'
				else
					result_70='Vulnerability'
				fi
			else
				echo "ServerTokens 설정 확인[2.4 이상 버전] -" $apache/conf.d/userdir.conf >> $CREATE_FILE 2>&1
				echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
				echo $apache/conf.d/userdir.conf" 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
				echo ' ' >> $CREATE_FILE 2>&1
			fi		
		fi
		
		rm -rf Tokens.txt
		
		if [ $result_70 = 'Vulnerability' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-148. 결과 : 취약" >> $CREATE_FILE 2>&1
		elif [ $result_70 = 'interview' ]; then
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-148. 결과 : 수동진단" >> $CREATE_FILE 2>&1
		else
			echo ' ' >> $CREATE_FILE 2>&1
			echo "★ SRV-148. 결과 : 양호" >> $CREATE_FILE 2>&1
		fi
		
	fi
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_75() {
  echo -n "SRV-158. 불필요한 TELNET 서비스 구동 여부 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-158. 불필요한 TELNET 서비스 구동 여부 " >> $CREATE_FILE 2>&1
  echo ":: 원격 접속 시 TELNET을 사용하지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls /etc/xinetd.d | grep "telnet" | wc -l` -gt 0 ]
        then
          for VVV in `ls /etc/xinetd.d | grep telnet | awk '{print $1}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "telnet 활성화되어 있습니다." >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
				echo "★ SRV-158. 결과 : 취약" >> $CREATE_FILE 2>&1
			  else
				echo "telnet 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
				echo " " >> $CREATE_FILE 2>&1
				echo "★ SRV-158. 결과 : 양호" >> $CREATE_FILE 2>&1
            fi
          done
		else
			echo "telnet 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
			echo " " >> $CREATE_FILE 2>&1
			echo "★ SRV-158. 결과 : 양호" >> $CREATE_FILE 2>&1
      fi
    elif [ -f /etc/inetd.conf ]
        then
          if [ `cat /etc/inetd.conf | grep -v '^ *#' | grep telnet | wc -l` -gt 0 ]
            then
              echo "telnet 활성화되어 있습니다." >> $CREATE_FILE 2>&1
			  echo " " >> $CREATE_FILE 2>&1
			  echo "★ SRV-158. 결과 : 취약" >> $CREATE_FILE 2>&1
			else
			  echo "telnet 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
			  echo " " >> $CREATE_FILE 2>&1
			  echo "★ SRV-158. 결과 : 양호" >> $CREATE_FILE 2>&1
          fi
    else
		echo "telnet 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
		echo " " >> $CREATE_FILE 2>&1
		echo "★ SRV-158. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1
  
  

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_76() {
	echo -n "SRV-159. 원격 접속 세션 타임아웃 미설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-159. 원격 접속 세션 타임아웃 미설정" >> $CREATE_FILE 2>&1
	echo ":: Session Timeout이 600초(10분) 이하로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	
	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	echo "" > account_sson.txt
	
	echo "① /etc/profile 파일설정" >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1	
	
	if [ -f /etc/profile ]
	then
		if [ `cat /etc/profile | egrep -i "TMOUT|TIMEOUT" | grep -v "^#" | wc -l` -eq 0 ]
		then
			echo "/etc/profile 파일 내 TMOUT/TIMEOUT 설정이 없습니다." >> $CREATE_FILE 2>&1
			echo "BAD1" >> account_sson.txt
			
		else
			cat /etc/profile | egrep -i "TMOUT|TIMEOUT" >> $CREATE_FILE 2>&1

			if [ `cat /etc/profile | grep -v "^#" | egrep -i "TMOUT|TIMEOUT" | awk -F= '$2<=600' | awk -F= '$2>0' | wc -l` -ge 1 ]
			then
				echo "GOOD" >> account_sson.txt
			else
				echo "BAD" >> account_sson.txt
			fi
		fi
	else
		echo "/etc/profile 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	if [ -f /etc/csh.login ]
	then
		echo "② /etc/csh.login 파일설정" >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1	

		if [ `cat /etc/csh.login | egrep -i "autologout" | grep -v "^#" | wc -l` -eq 0 ]
		then
			echo "/etc/csh.login 파일 내 autologout 설정이 없습니다." >> $CREATE_FILE 2>&1
			echo "BAD" >> account_sson.txt
			
		else
			cat /etc/csh.login | grep -i "autologout" >> $CREATE_FILE 2>&1

			if [ `cat /etc/csh.login | grep -v "^#" | grep -i 'autologout' | awk -F= '$2<=10' | awk -F= '$2>0' | wc -l` -ge 1  ]
			then
				echo "GOOD" >> account_sson.txt
			else
				echo "BAD" >> account_sson.txt
			fi
		fi

	elif [ -f /etc/csh.cshrc ]
	then
		echo "② /etc/csh.cshrc 파일설정" >> $CREATE_FILE 2>&1
		echo "----------------------------------------------------" >> $CREATE_FILE 2>&1	

		if [ `cat /etc/csh.cshrc | egrep -i "autologout" | grep -v "^#" | wc -l` -eq 0 ]
		then
			echo "/etc/csh.cshrc 파일 내 autologout 설정이 없습니다." >> $CREATE_FILE 2>&1
			echo "BAD" >> account_sson.txt
			
		else
			cat /etc/csh.cshrc | grep -i "autologout" >> $CREATE_FILE 2>&1

			if [ `cat /etc/csh.cshrc | grep -v "^#" | grep -i 'autologout' | awk -F= '$2<=10' | awk -F= '$2>0' | wc -l`-ge 1 ]
			then
				echo "GOOD" >> account_sson.txt
			else
				echo "BAD" >> account_sson.txt
			fi
		fi

	else
		echo "/etc/csh.login, /etc/csh.cshrc 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi
	
	echo " " >> $CREATE_FILE 2>&1

	if [ `cat account_sson.txt | grep "GOOD" | wc -l` -ge 1 ]
	then
		echo "★ SRV-159. 결과 : 양호" >> $CREATE_FILE 2>&1    
	else
		echo "★ SRV-159. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	rm -rf account_sson.txt

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_77() {
  echo -n "SRV-161. Ftpusers 파일 소유자 및 권한 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-161. Ftpusers 파일 소유자 및 권한 설정 " >> $CREATE_FILE 2>&1
  echo ":: ftpusers 파일의 소유자가 root이고, 권한이 640 이하인 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  
  if [ -f /etc/ftpd/ftpusers ]
    then
      ls -alL /etc/ftpd/ftpusers  >> $CREATE_FILE 2>&1
    else
      echo " /etc/ftpd/ftpusers 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/ftpusers ]
    then
      ls -alL /etc/ftpusers  >> $CREATE_FILE 2>&1
    else
      echo " /etc/ftpusers 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/vsftpd.ftpusers ]
    then
      ls -alL /etc/vsftpd.ftpusers  >> $CREATE_FILE 2>&1
    else
      echo " /etc/vsftpd.ftpusers 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

   echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/vsftpd/ftpusers ]
    then
      ls -alL /etc/vsftpd/ftpusers  >> $CREATE_FILE 2>&1
    else
      echo " /etc/vsftpd/ftpusers 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi
  
  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/vsftpd.user_list ]
    then
      ls -alL /etc/vsftpd.user_list >> $CREATE_FILE 2>&1
    else
      echo " /etc/vsftpd.user_list 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/vsftpd/user_list ]
    then
      ls -alL /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
    else
      echo " /etc/vsftpd/user_list 파일이 존재하지 않습니다."  >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1

  echo "  " > ftpusers.txt

  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/ftpd/ftpusers ]
    then
      if [ `ls -alL /etc/ftpd/ftpusers | awk '{print $1}' | grep '...-.-----' | wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
     fi
    else
      echo "no-file"  >> ftpusers.txt
  fi

  if [ -f /etc/ftpusers ]
    then
      if [ `ls -alL /etc/ftpusers | awk '{print $1}' | grep '...-.-----'| wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
      fi
    else
      echo "no-file"  >> ftpusers.txt
  fi

  if [ -f /etc/vsftpd.ftpusers ]
    then
      if [ `ls -alL /etc/vsftpd.ftpusers | awk '{print $1}' | grep '...-.-----' | wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
      fi
    else
      echo "no-file"  >> ftpusers.txt
  fi

  if [ -f /etc/vsftpd/ftpusers ]
    then
      if [ `ls -alL /etc/vsftpd/ftpusers | awk '{print $1}' | grep '...-.-----' | wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
      fi
    else
      echo "no-file"  >> ftpusers.txt
  fi
  
  if [ -f /etc/vsftpd.user_list ]
    then
      if [ `ls -alL /etc/vsftpd.user_list | awk '{print $1}' | grep '...-.-----' | wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
      fi
    else
      echo "no-file"  >> ftpusers.txt
  fi
  

 if [ -f /etc/vsftpd/user_list ]
    then
      if [ `ls -alL /etc/vsftpd/user_list | awk '{print $1}' | grep '...-.-----' | wc -l` -eq 0 ]
        then
          echo "BAD" >> ftpusers.txt
        else
          echo "GOOD" >> ftpusers.txt
      fi
    else
      echo "no-file"  >> ftpusers.txt
  fi


  if [ `cat ftpusers.txt | grep "BAD" | wc -l` -gt 0 ]
    then
      echo "★ SRV-161. 결과 : 취약" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-161. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  rm -rf ftpusers.txt


  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_78() {
  echo -n "SRV-162. 이벤트 로그에 대한 접근 권한 설정 미비 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-162. 이벤트 로그에 대한 접근 권한 설정 미비" >> $CREATE_FILE 2>&1
  echo ":: su 명령어의 사용 기록을 파일에 남기도록 설정되어 있는 경우" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  #20151113-01
  #Start
        if [ -f /etc/rsyslog.conf ]
                then
                        echo "☞ rsyslog 프로세스" >> $CREATE_FILE 2>&1
                        ps -ef | grep 'rsyslog' | grep -v 'grep' >> $CREATE_FILE 2>&1
                else
                        echo "☞ syslog 프로세스" >> $CREATE_FILE 2>&1
                        ps -ef | grep 'syslog' | grep -v 'grep' >> $CREATE_FILE 2>&1
        fi

          echo " " >> $CREATE_FILE 2>&1

          echo "☞ SU 로깅 설정" >> $CREATE_FILE 2>&1

        if [ -f /etc/rsyslog.conf ]
                then
                        if [ `cat /etc/rsyslog.conf | wc -l` -gt 0 ]
                                then
                                        if [ `cat /etc/rsyslog.conf | grep -v "^#" | grep -v '^$' | grep -w "authpriv." | wc -l` -gt 0 ]
                                                then
                                                        cat /etc/rsyslog.conf | grep -v "^#" | grep -v '^$' | grep -w "authpriv." >> $CREATE_FILE 2>&1
                                                        echo " " >> $CREATE_FILE 2>&1
                                                        echo "★ SRV-162. 결과 : 양호" >> $CREATE_FILE 2>&1
                                                else
                                                        echo "★ SRV-162. 결과 : 취약" >> $CREATE_FILE 2>&1
                                        fi
                                else
                                        echo "/etc/rsyslog.conf  파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
                        fi
                elif [ -f /etc/syslog.conf ]
                        then
                                if [ `cat /etc/syslog.conf | grep -v "^#" | grep -v '^$' | grep -w "authpriv." | wc -l` -gt 0 ]
                                        then
                                                cat /etc/rsyslog.conf | grep -v "^#" | grep -v '^$' | grep -w "authpriv." >> $CREATE_FILE 2>&1
                                                echo " " >> $CREATE_FILE 2>&1
                                                echo "★ SRV-162. 결과 : 양호" >> $CREATE_FILE 2>&1
                                        else
                                                echo "★ SRV-162. 결과 : 취약" >> $CREATE_FILE 2>&1
                                fi
                        else
                                echo "/etc/syslog.conf  파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1

        fi
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_79() {
  echo -n "SRV-163. 시스템 사용 주의사항 미출력 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-163. 시스템 사용 주의사항 미출력 " >> $CREATE_FILE 2>&1
  echo ":: 서버 및 Telnet 서비스에 로그온 메시지가 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  if [ -f /etc/issue.net ]
  then
		echo "☞ /etc/issue.net 확인(서버정보 출력여부 확인)" >> $CREATE_FILE 2>&1
		echo "☞ 서비스별 배너 경로 설정에 /etc/issue.net이 설정되어 있지 않으면 무관함 " >> $CREATE_FILE 2>&1
		cat /etc/issue.net >> $CREATE_FILE 2>&1
		echo "  " >> $CREATE_FILE 2>&1
  fi
  
  if [ -f /etc/issue ]
  then
		echo "☞ /etc/issue 확인(서버정보 출력여부 확인)" >> $CREATE_FILE 2>&1
		echo "☞ 서비스별 배너 경로 설정에 /etc/issue가 설정되어 있지 않으면 무관함 " >> $CREATE_FILE 2>&1
		cat /etc/issue >> $CREATE_FILE 2>&1
		echo "  " >> $CREATE_FILE 2>&1
  fi

  
  echo "☞ 서버 로그온 시 출력 배너(/etc/motd) 확인" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ -f /etc/motd ]
	then  
		if [ `cat /etc/motd | wc -l` -gt 0 ]
    	then
			 echo "GOOD" >> banner.txt
	   	 cat /etc/motd >> $CREATE_FILE 2>&1
		else
			echo
			echo "BAD" >> banner.txt 
		fi
  else
	  echo "/etc/motd 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	  echo "BAD" >> banner.txt
  fi
  
  echo "  " >> $CREATE_FILE 2>&1
  
  echo "☞ SSH 관련 설정 " >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  if [ `ps -ef | grep sshd | grep -v "grep" | wc -l` -eq 0 ]
	  then
		  echo "☞ SSH 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
	  else
		  echo "☞ SSH 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1
		  echo "  " >> $CREATE_FILE 2>&1
          echo "■ ssh 배너 연동 여부" >> $CREATE_FILE 2>&1		  
		  cat ssh-banner.txt >> $CREATE_FILE 2>&1
		  
		  echo "  " >> $CREATE_FILE 2>&1
		  echo "■ 연동된 ssh 배너파일 존재시 해당 파일 내용" >> $CREATE_FILE 2>&1
		  
		  if [ `cat ssh-banner.txt | grep -v "^#" | wc -l` -gt 0 ]
		  then
			#170201
			ssh_path=`cat ssh-banner.txt | grep -v "^#" | awk -F' ' '{print $4}'`
			cat $ssh_path >> $CREATE_FILE 2>&1
			echo "GOOD" >> banner.txt
		  else
			echo "ssh 배너 연동이 적절하지 않습니다." >> $CREATE_FILE 2>&1
			echo "BAD" >> banner.txt
		  fi
  fi
 
  ps -ef | grep telnetd  | grep -v grep >> banner_temp.txt
  
  if [ -f /etc/inetd.conf ]
  then
  cat /etc/inetd.conf | grep 'telnetd' | grep -v '#' >> banner_temp.txt
  fi
  
   echo "  " >> $CREATE_FILE 2>&1

  
  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | grep "telnet" | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | grep telnet | awk '{print $9}'`
          do
            if [ `cat $VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "telnet 활성화되어 있습니다." >> telnetps.txt
            fi
          done
      fi
    else
      if [ -f /etc/inetd.conf ]
        then
          if [ `cat /etc/inetd.conf | grep -v '^ *#' | grep telnet | wc -l` -gt 0 ]
            then
              echo "telnet 활성화되어 있습니다." >> telnetps.txt
          fi
      fi
  fi

  echo " " >> $CREATE_FILE 2>&1

  ps -ef | grep telnetd  | grep -v grep >> telnetps.txt
  cat /etc/issue >> telnetbanner.txt
  cat /etc/issue.net >> telnetbanner.txt

  if [ `cat telnetps.txt | grep telnet | grep -v grep | wc -l` -gt 0 ]
    then
      echo "☞ Telnet 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1
      echo "■ TELNET 배너" >> $CREATE_FILE 2>&1
      if [ `cat telnetbanner.txt | egrep "Linux|Kernel" | grep -v grep | wc -l` -eq 0 ]
        then
          echo "GOOD" >> banner.txt
          ls -al /etc/issue >> $CREATE_FILE 2>&1
          cat /etc/issue >> $CREATE_FILE 2>&1
          echo " " >> $CREATE_FILE 2>&1
          ls -al /etc/issue.net >> $CREATE_FILE 2>&1
          cat /etc/issue.net >> $CREATE_FILE 2>&1
        else
          echo "BAD" >> banner.txt
          ls -al /etc/issue >> $CREATE_FILE 2>&1
          cat /etc/issue >> $CREATE_FILE 2>&1
          echo " " >> $CREATE_FILE 2>&1
          ls -al /etc/issue.net >> $CREATE_FILE 2>&1
          cat /etc/issue.net >> $CREATE_FILE 2>&1
      fi
    else
      echo "GOOD" >> banner.txt
      echo "☞ Telnet 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo "  " >> $CREATE_FILE 2>&1
  echo "  " >> $CREATE_FILE 2>&1

  if [ -d /etc/xinetd.d ]
    then
      if [ `ls -alL /etc/xinetd.d | grep "ftp" | wc -l` -gt 0 ]
        then
          for VVV in `ls -alL /etc/xinetd.d | grep ftp | grep -v "tftp" | awk '{print $9}'`
          do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
              then
                echo "ftp 활성화되어 있습니다." >> ftpps.txt
                echo "/etc/xinetd.d/ FTP 구동 정보" >> $CREATE_FILE 2>&1
                ls -alL /etc/xinetd.d | grep ftp | grep -v "tftp" >> $CREATE_FILE 2>&1
                cat /etc/xinetd.d/$VVV | grep -i "disable" >> $CREATE_FILE 2>&1
            fi
          done
      fi
    else
      if [ -f /etc/inetd.conf ]
        then
          if [ `cat /etc/inetd.conf | grep -v '#' | grep ftp  | grep -v "tftp" |  wc -l` -gt 0  ]
            then
              echo "ftp 활성화되어 있습니다." >> ftpps.txt
          fi
      fi
  fi

  ps -ef | grep ftp  | grep -v grep | grep -v "tftp" >> ftpps.txt
  echo " " >> $CREATE_FILE 2>&1

  if [ `cat ftpps.txt | grep ftp | grep -v grep | wc -l` -gt 0 ]
    then
      echo "☞ FTP 서비스 활성화되어 있습니다" >> $CREATE_FILE 2>&1
      echo "■ FTP 배너" >> $CREATE_FILE 2>&1

      if [ -f /etc/welcome.msg ]
        then
          if [ `cat /etc/welcome.msg | grep -i "banner" | grep "=" | grep "\".\"" | wc -l` -eq 0 ]
            then
              echo "BAD" >> banner.txt
              cat /etc/welcome.msg >> $CREATE_FILE 2>&1
              echo " " >> $CREATE_FILE 2>&1
            else
              echo "GOOD" >> banner.txt
              cat /etc/welcome.msg >> $CREATE_FILE 2>&1
              echo " " >> $CREATE_FILE 2>&1
          fi
        else
          if [ -f /etc/vsftpd.conf ]
            then
              if [ `cat /etc/vsftpd.conf | grep -i "ftp_banner" | grep "=" | wc -l` -eq 0 ]
                then
                  echo "BAD" >> banner.txt
                  cat /etc/vsftpd.conf | grep -i "ftp_banner" >> $CREATE_FILE 2>&1
                else
                  echo "GOOD" >> banner.txt
                  cat /etc/vsftpd.conf | grep -i "ftp_banner" >> $CREATE_FILE 2>&1
              fi
            else
              if [ -f /etc/proftpd.conf ]
                then
                  if [ `cat /etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -eq 0 ]
                    then
                      echo "BAD" >> banner.txt
                      cat /etc/proftpd.conf | grep -i "Serverldent" >> $CREATE_FILE 2>&1
                    else
              	      echo "GOOD" >> banner.txt
                      cat /etc/proftpd.conf  | grep -i "Serverldent" >> $CREATE_FILE 2>&1
                  fi
                else
                  if [ -f /usr/local/etc/proftpd.conf ]
                    then
                      if [ `cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -eq 0 ]
                        then
                          echo "BAD" >> banner.txt
                          cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" >> $CREATE_FILE 2>&1
                        else
              	          echo "GOOD" >> banner.txt
              	          cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" >> $CREATE_FILE 2>&1
                      fi
                    else
                      if [ -f /etc/ftpaccess ]
                        then
                          if [ `cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" | wc -l` -eq 0 ]
                            then
                              echo "BAD" >> banner.txt
                              cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" >> $CREATE_FILE 2>&1
                            else
              	              echo "GOOD" >> banner.txt
                              cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" >> $CREATE_FILE 2>&1
                          fi
                        else
                          echo "미점검" >> banner.txt
                      fi
                  fi
              fi
          fi
      fi
    else
      echo "GOOD" >> banner.txt
      echo "☞ FTP 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi


  echo " " > banner_temp.txt
  echo "  " >> $CREATE_FILE 2>&1

  if [ `ps -ef | grep sendmail | grep -v grep | wc -l` -gt 0 ]
    then
      echo "☞ SMTP 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1
      echo "■ SMTP 배너" >> $CREATE_FILE 2>&1
      if [ -f /etc/mail/sendmail.cf ]
        then
          if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep -i "Sendmail" | wc -l` -gt 0 ]
            then
              echo "BAD" >> banner.txt
              echo "/etc/mail/sendmail.cf 파일 내용" >> $CREATE_FILE 2>&1
              cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
            else
              echo "GOOD" >> banner.txt
              echo "/etc/mail/sendmail.cf 파일 내용" >> $CREATE_FILE 2>&1
              cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" >> $CREATE_FILE 2>&1
          fi
        else
          echo "미점검" >> banner.txt
          echo "/etc/mail/sendmail.cf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
      fi
    else
      echo "GOOD" >> banner.txt
      echo "☞ SMTP 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi


  echo "  " >> $CREATE_FILE 2>&1

  if [ `ps -ef | grep named | grep -v grep | wc -l` -gt 0 ]
    then
      echo "☞ DNS 서비스 활성화되어 있습니다." >> $CREATE_FILE 2>&1
      echo "■ DNS 배너" >> $CREATE_FILE 2>&1
      if [ -f /etc/named.conf ]
        then
          if [ `cat /etc/named.conf | grep "version" | wc -l` -eq 0 ]
            then
              echo "BAD" >> banner.txt
              echo "/etc/named.conf 파일 내용" >> $CREATE_FILE 2>&1
              echo "/etc/named.conf 파일 설정 없음" >> $CREATE_FILE 2>&1
            else
              echo "GOOD" >> banner.txt
              echo "/etc/named.conf 파일 내용" >> $CREATE_FILE 2>&1
              cat /etc/named.conf | grep -i "version" >> $CREATE_FILE 2>&1
          fi
        else
          echo "미점검" >> banner.txt
          echo "/etc/named.conf 파일 존재하지 않습니다." >> $CREATE_FILE 2>&1
      fi
    else
      echo "GOOD" >> banner.txt
      echo "☞ DNS 서비스 비활성화되어 있습니다." >> $CREATE_FILE 2>&1
  fi

  echo "  " >> $CREATE_FILE 2>&1

  if [ `cat banner.txt | grep "GOOD" | wc -l` -eq 4 ]
    then
      echo "★ SRV-163. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-163. 결과 : 수동진단" >> $CREATE_FILE 2>&1
  fi

  rm -rf ssh-banner.txt
  rm -rf banner.txt
  rm -rf banner_temp.txt
  rm -rf telnetbanner.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_80() {
	echo -n "SRV-164. 계정이 존재하지 않는 GID 금지 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-164. 계정이 존재하지 않는 GID 금지" >> $CREATE_FILE 2>&1
	echo ":: 구성원이 없거나, 더 이상 사용하지 않는 그룹을 삭제한 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	
	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
    
	echo "☞ /etc/group 파일 내역 " >> $CREATE_FILE 2>&1
	cat /etc/group >> $CREATE_FILE 2>&1
	
	echo " " >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	echo "☞ /etc/passwd 파일 내역 " >> $CREATE_FILE 2>&1
	cat /etc/passwd >> $CREATE_FILE 2>&1
	
	echo " " >> $CREATE_FILE 2>&1
	
	echo "☞ 구성원이 존재하지 않는 그룹 " >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	awk -F: '$4==null' /etc/group | awk -F":" '$3 >= 500' | grep -v "^#" > no_4.txt
	awk -F: '{print $3}' no_4.txt > gid_group.txt 
	
	if [ -f gid_group.txt ] 
	 then 
	     for D in `cat gid_group.txt` 
	     do 
		   awk -F: '{print $4}' /etc/passwd | grep -w $D > gid_1.txt 

		if [ `cat gid_1.txt | wc -l` -gt 0 ]
		then 
			echo "gid=$D"  > /dev/null 
		else 
			echo $D >> gid_none.txt 
		fi 
	done
	fi

	echo " " >> $CREATE_FILE 2>&1
	
	if [ -f gid_none.txt ]
	  then
	    if [ `cat gid_none.txt | wc -l` -gt 0 ]
	      then
		    for A in `cat gid_none.txt` 
		    do
			awk -F: '{print $1, $3}' /etc/group | grep -w $A >> $CREATE_FILE 2>&1  
		    done 
         	echo " " >> $CREATE_FILE 2>&1
		    echo "★ SRV-164. 결과 : 취약" >> $CREATE_FILE 2>&1 
	      else
		echo " " >> $CREATE_FILE 2>&1
		echo "★ SRV-164. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi
	else
		echo "★ SRV-164. 결과 : 양호" >> $CREATE_FILE 2>&1
	fi
	
	rm -rf no_4.txt
	rm -rf gid_group.txt 
	rm -rf gid_none.txt 
	rm -rf gid_1.txt   

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_81() {
	echo -n "SRV-165. 사용자 shell 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-165. 사용자 shell 점검" >> $CREATE_FILE 2>&1
	echo ":: 로그인이 필요하지 않은 계정에 /bin/false(nologin) 쉘이 부여되어 있는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
	
	echo " " >> $CREATE_FILE 2>&1
	if [ -f /etc/passwd ]
	then
		cat /etc/passwd | egrep "^daemon|^bin|^sys|^adm|^listen|^nobody|^nobody4|^noaccess|^diag|^listen|^operator|^games|^gopher" | grep -v "admin" >> $CREATE_FILE 2>&1
	else
		echo "/etc/passwd 파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	if [ `cat /etc/passwd | egrep "^daemon|^bin|^sys|^adm|^listen|^nobody|^nobody4|^noaccess|^diag|^listen|^operator|^games|^gopher" |  awk -F: '{print $7}'| egrep -v 'admin|false|nologin|null|halt|sync|shutdown' | wc -l` -eq 0 ]
	then
		echo "★ SRV-165. 결과 : 양호" >> $CREATE_FILE 2>&1
	else
		echo "★ SRV-165. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi
	

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_82() {
  echo -n "SRV-166. 숨겨진 파일 및 디렉토리 검색 및 제거 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-166. 숨겨진 파일 및 디렉토리 검색 및 제거 " >> $CREATE_FILE 2>&1
  echo ":: 디렉터리 내 숨겨진 파일을 확인하여, 불필요한 파일 삭제를 완료한 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "☞ 숨겨진 파일 및 디렉터리 현황" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1

 #find /tmp -name ".*" -ls  > hidden-file.txt
  find /home -name ".*" -ls | egrep -v ".bash|viminfo|mozilla" >> hidden-file.txt
  find /usr -name ".*" -ls |  grep -v "root" | grep -v "var" >> hidden-file.txt
  find /var -name ".*" -ls |  grep -v "root" | grep -v "var" >> hidden-file.txt
  find /bin -name ".*" -ls |  grep -v "root" | grep -v "var" >> hidden-file.txt
  find /sbin -name ".*" -ls |  grep -v "root" | grep -v "var" >> hidden-file.txt
  echo " " >> $CREATE_FILE 2>&1

  if [ -s hidden-file.txt ]
    then
      cat hidden-file.txt >> $CREATE_FILE 2>&1
      echo " " >> $CREATE_FILE 2>&1
      echo "★ SRV-166. 결과 : 수동진단" >> $CREATE_FILE 2>&1
      rm -rf hidden-file.txt
    else
      echo "★ SRV-166. 결과 : 양호" >> $CREATE_FILE 2>&1
  fi

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_83() {
  echo -n "SRV-168. 정책에 따른 시스템 로깅 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-168. 정책에 따른 시스템 로깅 설정" >> $CREATE_FILE 2>&1
  echo ":: 로그 기록 정책이 정책에 따라 설정되어 수립되어 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1

  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  #20151113-01 
  #Start 
	if [ -f /etc/rsyslog.conf ]
		then	
			echo "☞ rsyslog 프로세스" >> $CREATE_FILE 2>&1
			ps -ef | grep 'rsyslog' | grep -v 'grep' >> $CREATE_FILE 2>&1
		else
			echo "☞ syslog 프로세스" >> $CREATE_FILE 2>&1
			ps -ef | grep 'syslog' | grep -v 'grep' >> $CREATE_FILE 2>&1
	fi

  echo " " >> $CREATE_FILE 2>&1

  echo "☞ 시스템 로깅 설정" >> $CREATE_FILE 2>&1

	if [ -f /etc/rsyslog.conf ]
		then
			if [ `cat /etc/rsyslog.conf | wc -l` -gt 0 ]
				then 
					cat /etc/rsyslog.conf | grep -v "^#" | grep -v '^$' >> $CREATE_FILE 2>&1
				else
					echo "/etc/rsyslog.conf  파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
			fi
		elif [ -f /etc/syslog.conf ]
			then
				cat /etc/syslog.conf | grep -v "^#" | grep -v '^$' >> $CREATE_FILE 2>&1
			else	
				echo "/etc/syslog.conf  파일이 존재하지 않습니다." >> $CREATE_FILE 2>&1
		
	fi
	

  echo " " >> $CREATE_FILE 2>&1

  echo " " > syslog.txt
	if [ -f /etc/syslog.conf ] 
		then
			if [ `cat /etc/syslog.conf | egrep "info|alert|notice|debug" | egrep "var|log" | grep -v "^#" | wc -l` -gt 0 ]
				then
					echo "GOOD" >> syslog.txt
			else
				echo "BAD" >> syslog.txt
			fi
					
			if [ `cat /etc/syslog.conf | egrep "alert|err|crit" | egrep "console|sysmsg" | grep -v "^#" | wc -l` -gt 0 ]
				then
					echo "GOOD" >> syslog.txt
			else
				echo "BAD" >> syslog.txt
			fi

			if [ `cat /etc/syslog.conf | grep "emerg" | grep "\*" | grep -v "^#" | wc -l` -gt 0 ]
				then
					echo "GOOD" >> syslog.txt
			else 
				echo "BAD" >> syslog.txt
			fi
			
		elif [ -f /etc/rsyslog.conf ]
			then
				if [ `cat /etc/rsyslog.conf | egrep "info|alert|notice|debug" | egrep "var|log" | grep -v "^#" | wc -l` -gt 0 ]
					then
						echo "GOOD" >> syslog.txt
				else
					echo "BAD" >> syslog.txt
				fi
				if [ `cat /etc/rsyslog.conf | egrep "alert|err|crit" | egrep "console|sysmsg" | grep -v "^#" | wc -l` -gt 0 ]
					then
						echo "GOOD" >> syslog.txt
				else
					echo "BAD" >> syslog.txt
				fi
				if [ `cat /etc/rsyslog.conf | grep "emerg" | grep "\*" | grep -v "^#" | wc -l` -gt 0 ]
					then
						echo "GOOD" >> syslog.txt
				else
					echo "BAD" >> syslog.txt
				fi
									
		else
			echo "BAD" >> syslog.txt
	fi
  echo " " >> $CREATE_FILE 2>&1

  if [ `cat syslog.txt | grep "BAD" | wc -l` -eq 0 ]
    then
      echo "★ SRV-168. 결과 : 양호" >> $CREATE_FILE 2>&1
    else
      echo "★ SRV-168. 결과 : 취약" >> $CREATE_FILE 2>&1
  fi
#end 

  rm -rf syslog.txt

  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_84() {
	echo -n "SRV-069. 비밀번호 관리정책 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-069. 비밀번호 관리정책 점검" >> $CREATE_FILE 2>&1
	echo ":: /etc/login.defs 파일 내에 다음 항목들이 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
	echo "PASS_MAX_DAYS : 패스워드 사용 가능 기간(일)" >> $CREATE_FILE 2>&1
	echo "PASS_MIN_DAYS : 패스워드 변경 가능 최소기간(일)" >> $CREATE_FILE 2>&1
	echo "PASS_MIN_LEN : 패스워드 최소 길이" >> $CREATE_FILE 2>&1
	echo "PASS_WARN_AGE : 패스워드 만료 표시 기간(일)" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1 
	echo " " >> $CREATE_FILE 2>&1

	echo "패스워드 복잡도 설정 확인 : /etc/login.defs " >> $CREATE_FILE 2>&1
	echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
	cat /etc/login.defs | egrep -i "PASS_MAX_DAYS|PASS_MIN_DAYS|PASS_MIN_LEN|PASS_WARN_AGE" | grep -v "^#" >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	
	echo "★ SRV-069. 결과 : 수동진단" >> $CREATE_FILE 2>&1

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_85() {
echo "SRV-074. 관리되지 않는 계정 및 비밀번호 점검 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
echo "==============================================================================" >> $CREATE_FILE 2>&1
echo "SRV-074. 관리되지 않는 계정 및 비밀번호 점검" >> $CREATE_FILE 2>&1
echo ":: 불필요한 계정이 존재하지 않는 경우 양호" >> $CREATE_FILE 2>&1
echo ":: 패스워드 최대 사용기간이 90일(12주) 이하로 설정되어 있을 경우 양호" >> $CREATE_FILE 2>&1
echo "(필요한 경우) 패스워드 최소 사용기간이 1일(1주) 이상으로 설정되어 있을 경우 양호" >> $CREATE_FILE 2>&1
echo "==============================================================================" >> $CREATE_FILE 2>&1

echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "① 기본 시스템 계정(adm, sync, shutdown, halt, news, operator, games, gopher, nfsnobody, squid, guest) " >> $CREATE_FILE 2>&1
echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
if [ `cat /etc/passwd | egrep -v "false|nologin" | egrep "^adm:|^sync:|^shutdown:|^halt:|^news:|^operator:|^games:|^gopher:|^nfsnobody:|^squid:|^guest:"| wc -l` -eq 0 ]; then
	echo "불필요한 기본 시스템 계정이 존재하지 않습니다." >> $CREATE_FILE 2>&1
	echo "good" >> Limesec_id.txt 2>&1 
else
	cat /etc/passwd  | egrep -v "false|nologin" | egrep "^adm:|^sync:|^shutdown:|^halt:|^news:|^operator:|^games:|^gopher:|^nfsnobody:|^squid:|^guest:" >> $CREATE_FILE 2>&1
	echo "bad" >> Limesec_id.txt 2>&1 
fi
echo " " >> $CREATE_FILE 2>&1

echo "② 서버계정 리스트 " >> $CREATE_FILE 2>&1
echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
cat /etc/passwd | egrep -v "false|nologin" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "③ 계정 접속 로그(lastlog) " >> $CREATE_FILE 2>&1
echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
lastlog >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "④ 패스워드 최대·최소 사용기간 설정" >> $CREATE_FILE 2>&1
echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
if [ -f /etc/login.defs ]; then
	echo "☞ 패스워드 설정 현황" >> $CREATE_FILE 2>&1
		if [ `cat /etc/login.defs | grep -i "PASS_MAX_DAYS" | grep -v "^#" | wc -l` -ne 0 ]; then
			cat /etc/login.defs | grep -i "PASS_MAX_DAYS" | grep -v "^#" >> $CREATE_FILE 2>&1
			cat /etc/login.defs | grep -i "PASS_MIN_DAYS" | grep -v "^#" >> $CREATE_FILE 2>&1
		else
			echo "패스워드 최대 사용기간 설정이 되어있지 않습니다." >> $CREATE_FILE 2>&1
		fi
else
	echo " /etc/login.defs 파일이 존재하지 않습니다. " >> $CREATE_FILE 2>&1
fi
echo " " >> $CREATE_FILE 2>&1

if [ -f /etc/login.defs ]; then
	pass_max_days=`cat /etc/login.defs | grep -i "PASS_MAX_DAYS" | grep -v "^#" | awk '{print $2}'`
	if [ $pass_max_days -gt 0 ] && [ $pass_max_days -le 90 ]; then
		echo "GOOD" >> Limesec_id.txt 2>&1	
	else
		echo "BAD" >> Limesec_id.txt 2>&1
	fi
else
	echo "bad" >> Limesec_id.txt 2>&1
fi

if [ `cat Limesec_id.txt | grep "bad" | wc -l` -eq 0 ]; then
	echo "★ SRV-074. 결과 : 양호" >> $CREATE_FILE 2>&1
else
	echo "★ SRV-074. 결과 : 수동진단" >> $CREATE_FILE 2>&1
fi

rm -rf Limesec_id.txt

echo " " >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo "완료"
echo " "
}

U_86() {
  echo "SRV-075. 유추가능한 비밀번호 사용 여부  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-075. 유추가능한 비밀번호 사용 여부 " >> $CREATE_FILE 2>&1
  echo ":: 쉽게 유추가능한 비밀번호를 사용하지 않는 경우 양호" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1
 
  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
 
  echo "해당항목은 운영담당자와 인터뷰를 통해서 점검 진행" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "[참조]" >> $CREATE_FILE 2>&1
  echo "☞ 패스워드 미설정 계정" >> $CREATE_FILE 2>&1
  echo "----------------------------------------------------" >> $CREATE_FILE 2>&1
  cat /etc/shadow >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "비밀번호 복잡성 설정 확인 : /etc/pam.d/system-auth " >> $CREATE_FILE 2>&1
  cat /etc/pam.d/system-auth | egrep -i "minlen|dcredit|ucredit|lcredit|ocredit" | grep -v "^#" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "★ SRV-075. 결과 : 수동진단" >> $CREATE_FILE 2>&1
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}

U_87() {
	echo -n "SRV-127. 계정 잠금 임계값 설정 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
	echo "==============================================================================" >> $CREATE_FILE 2>&1
	echo "SRV-127. 계정 잠금 임계값 설정" >> $CREATE_FILE 2>&1
	echo ":: 계정 잠금 임계값이 5이하의 값으로 설정되어 있는 경우 양호" >> $CREATE_FILE 2>&1
	echo "==============================================================================" >> $CREATE_FILE 2>&1

	echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1 
	echo " " >> $CREATE_FILE 2>&1

	releaseString=$(uname -a)

	if echo $releaseString | egrep -qe 'el5|el6|el7';
	then		
		if [ `cat /etc/pam.d/system-auth | egrep "pam_tally.so|pam_tally2.so" | grep -v "^#" | wc -l` -gt 0 ]
		 then
			cat /etc/pam.d/system-auth | egrep "pam_tally.so|pam_tally2.so" | grep -v "^#" >> $CREATE_FILE 2>&1
		 else 
		 	if [ `cat /etc/pam.d/system-auth | grep "pam_faillock.so" | grep -v "^#" | wc -l` -gt 0 ]
		      then
			    cat /etc/pam.d/system-auth | grep "pam_faillock.so" | grep -v "^#" >> $CREATE_FILE 2>&1
		      else
			    echo "/etc/pam.d/system-auth 파일에 설정값이 없습니다." >> $CREATE_FILE 2>&1
		    fi		 	
		fi
		
		echo " " >> $CREATE_FILE 2>&1
		
		if [ `cat /etc/pam.d/system-auth | grep -v '^#' | egrep "pam_tally.so|pam_tally2.so|pam_faillock.so" | wc -l` -gt 0 ]
		then
			if [ `cat /etc/pam.d/system-auth | grep -v '^#' | egrep "deny=[1-5]" | wc -l` -gt 0 ]
			then  
				echo "★ SRV-127. 결과 : 양호" >> $CREATE_FILE 2>&1
			else
				echo "★ SRV-127. 결과 : 취약" >> $CREATE_FILE 2>&1
			fi
		else
			echo "★ SRV-127. 결과 : 취약" >> $CREATE_FILE 2>&1
		fi
	else
		echo "★ SRV-127. 결과 : 취약" >> $CREATE_FILE 2>&1
	fi

	echo " " >> $CREATE_FILE 2>&1
	echo " " >> $CREATE_FILE 2>&1
	echo "완료"
	echo " "
}

U_88() {
  echo -n "SRV-118. 최신 보안패치 및 벤더 권고사항 적용 >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
  echo "==============================================================================" >> $CREATE_FILE 2>&1
  echo "SRV-118. 최신 보안패치 및 벤더 권고사항 적용 " >> $CREATE_FILE 2>&1
  echo ":: 패치 적용 정책을 수립하여 주기적으로 패치를 관리하고 있는 경우 양호" >> $CREATE_FILE 2>&1
  echo ":: 아래 설치된 패키지 목록 현황 검토 후 담당자와 인터뷰 진행" >> $CREATE_FILE 2>&1
  echo "==============================================================================" >> $CREATE_FILE 2>&1


  echo "▶ 시스템 현황" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "해당항목은 운영담당자와 인터뷰를 통해서 점검 진행" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1

  echo "★ SRV-118. 결과 : 수동진단" >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1  
  
  echo " " >> $CREATE_FILE 2>&1
  echo " " >> $CREATE_FILE 2>&1
  echo "완료"
  echo " "
}


U_01
U_02
U_03
U_04
U_05
U_06
U_07
U_08
U_09
U_10
U_11
U_12
U_13
U_14
U_15
U_16
U_17
U_18
U_19
U_20
U_21
U_22
U_23
U_24
U_25
U_26
U_27
U_28
U_29
U_30
U_31
U_32
U_33
U_34
U_35
U_36
U_37
U_38
U_39
U_40
U_41
U_42
U_43
U_44
U_45
U_46
U_47
U_48
U_49
U_50
U_51
U_52
U_53
U_54
U_55
U_56
U_57
U_58
U_59
U_60
U_61
U_62
U_63
U_64
U_65
U_66
U_67
U_68
U_69
U_70
U_71
U_72
U_73
U_74
U_75
U_76
U_77
U_78
U_79
U_80
U_81
U_82
U_83
U_84
U_85
U_86
U_87
U_88



echo "#################################  IP 정보  ##################################" >> $CREATE_FILE 2>&1
ifconfig -a >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "#################################  네트워크 현황 ###############################" >> $CREATE_FILE 2>&1
netstat -an | egrep -i "LISTEN|ESTABLISHED" >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "################################## 라우팅 정보 #################################" >> $CREATE_FILE 2>&1
netstat -rn >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "################################## 프로세스 현황 ###############################" >> $CREATE_FILE 2>&1
ps -ef >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "################################## 사용자 환경 #################################" >> $CREATE_FILE 2>&1
env >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1

echo "##################################  웹 정보  ##################################" >> $CREATE_FILE 2>&1
# 아파치 전문 출력
if [ $path = 'ok' ]; then
	ls $conf >> $CREATE_FILE 2>&1
	cat $conf >> $CREATE_FILE 2>&1
fi
echo " " >> $CREATE_FILE 2>&1
echo "##################################  추가 파일 정보  ##################################" >> $CREATE_FILE 2>&1
echo '==========[ /etc/security/user 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/security/user >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/pam.d/login 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/pam.d/login >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/pam.d/system-auth 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/pam.d/system-auth >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/passwd 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/passwd >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/group 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/group >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/shadow 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/shadow >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/profile 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/profile >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/csh.login =========='>> $CREATE_FILE 2>&1
cat /etc/csh.login >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/csh.cshrc =========='>> $CREATE_FILE 2>&1
cat /etc/csh.cshrc >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/hosts 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/hosts >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/inetd.conf =========='>> $CREATE_FILE 2>&1
cat /etc/inetd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/hosts.equiv 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/hosts.equiv >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/hosts.allow 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/hosts.allow >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/hosts.deny 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/hosts.deny >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/bashrc 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/bashrc >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/vsftpd.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/vsftpd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/vsftpd/vsftpd.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/vsftpd/vsftpd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/exports 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/exports >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/mail/sendmail.cf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/mail/sendmail.cf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/named.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/named.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/named.boot 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/named.boot >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/services 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/services >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/vsftpd.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/vsftpd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/proftpd.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/proftpd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/ftpd/ftpusers 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/ftpd/ftpusers  >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/ftpusers 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/ftpusers >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/vsftpd/user_list 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/vsftpd/user_list >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/issue.net 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/issue.net >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/issue 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/issue >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/motd 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/motd >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/inetd.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/inetd.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/welcome.msg 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/welcome.msg >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/syslog.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/syslog.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/rsyslog.conf 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/rsyslog.conf >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ /etc/ssh/sshd_config 파일 현황 ]==========' >> $CREATE_FILE 2>&1
cat /etc/ssh/sshd_config >> $CREATE_FILE 2>&1
echo " " >> $CREATE_FILE 2>&1
echo '==========[ 설치된 패키지 목록 현황 ]==========' >> $CREATE_FILE 2>&1
echo "1) RPM " >> $CREATE_FILE 2>&1
echo "========================================" >> $CREATE_FILE 2>&1
rpm -qa --queryformat "%{Name} : (%{Version}|%{Release}) |(%{installtime:date})\n" | sort > rpm_list.txt 2>&1
    
echo "[참조] 설치된 패키지명: (버전|릴리즈) | (설치일자:요일_월/일/시간/연도)" >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1
cat rpm_list.txt >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1

echo "2) apt " >> $CREATE_FILE 2>&1
echo "========================================" >> $CREATE_FILE 2>&1
apt list | sort > apt_list.txt 2>&1
    
echo "[참조] 설치된 패키지명 현황" >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1
cat apt_list.txt >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1

echo "3) dpkg " >> $CREATE_FILE 2>&1
echo "========================================" >> $CREATE_FILE 2>&1
dpkg -l | sort > dpkg_list.txt 2>&1
    
echo "[참조] 설치된 패키지 현황" >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1
cat dpkg_list.txt >> $CREATE_FILE 2>&1
echo "========================================================" >> $CREATE_FILE 2>&1


echo " " >> $CREATE_FILE 2>&1

echo "☞ 진단작업이 완료되었습니다. 수고하셨습니다!"

# "***************************************  전체 결과물 파일 생성 시작  ***********************************"
 
_HOSTNAME=`hostname`
CREATE_FILE_RESULT=${_HOSTNAME}"-Linux-result".txt
echo > $CREATE_FILE_RESULT

echo " "
cat $CREATE_FILE >> $CREATE_FILE_RESULT 2>&1
echo "***************************************  전체 결과물 파일 생성 끝 **************************************"

unset FILES
unset HOMEDIRS
unset SERVICE_INETD
unset SERVICE
unset APROC1
unset APROC
unset ACONF
unset AHOME
unset ACFILE
unset ServiceDIR
unset vsfile
unset profile
unset result

rm -Rf list.txt
rm -Rf result.txt
rm -Rf telnetps.txt ftpps.txt
rm -Rf vsftpd.txt
rm -Rf apa_Manual.txt
rm -Rf error.txt
rm -Rf pathinfo.txt
rm -rf rpm_list.txt
rm -rf apt_list.txt
rm -rf dpkg_list.txt

rm -Rf $CREATE_FILE 2>&1

