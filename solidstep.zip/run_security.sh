#!/bin/bash

echo '######################################'
echo '#######   Install  SolidStep   #######'
echo '######################################'
sudo tar xf ./solidstep_agent_linux.tar -C /tmp
/usr/bin/sudo /usr/bin/su - root -c 'cd /tmp/linux && ./Install.sh 2 0 /SSR'
sudo rm -rf /tmp/solidstep_agent_linux.tar /tmp/linux 


echo '######################################'
echo '#######   Security Settings    #######'
echo '######################################'
echo "Fix SRV-027"
cat <<EOF | sudo tee /etc/hosts.deny > /dev/null
ALL:ALL
EOF

cat <<EOF | sudo tee /etc/hosts.allow > /dev/null
sshd: 10.1.0.0/16
sshd: 10.252.0.0/16
sshd: 10.9.0.0/16
sshd: 10.17.16.0/20
sshd: 10.12.0.0/16
sshd: 10.4.16.0/21
sshd: 10.253.0.0/16
EOF

echo "Fix SRV-067"
sudo sed -i 's/authtok_type=/authtok_type="minlen=9 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1"/g' /etc/pam.d/system-auth
sudo sed -i 's/PASS_MIN_DAYS[\t[:space:]]0/PASS_MIN_DAYS\t1/g' /etc/login.defs
sudo sed -i 's/PASS_MAX_DAYS[\t[:space:]]99999/PASS_MAX_DAYS\t90/g' /etc/login.defs

echo "Fix SRV-074"
#openssl rand -base64 32 | xargs echo root: | sudo chpasswd
echo 'root:HCPDEVOPS!2021' | sudo chpasswd > /dev/null

echo "Fix SRV-091"
sudo chmod 0755 /sbin/unix_chkpwd /usr/bin/at /usr/bin/newgrp
# ls -al /sbin/unix_chkpwd /usr/bin/at /usr/bin/newgrp

echo "Fix SRV-107"
sudo chmod 0640 /etc/at.deny

echo "Fix SRV-108"
cat <<EOF | sudo tee -a /usr/lib/systemd/rhel-dmesg > /dev/null
chmod 644 /var/log/wtmp*
EOF
sudo chmod 644 /var/log/wtmp*

echo "Fix SRV-122"
cat <<EOF | sudo tee -a /etc/profile >> /dev/null
umask 022
export umask
EOF

echo "Fix SRV-127"
echo "LOGIN_RETRIES   3" | sudo tee -a /etc/login.defs > /dev/null
sudo sed -i 's/auth        required      pam_deny.so/auth        required      pam_faillock.so preauth silent audit deny=3 unlock_time=120 auth sufficient pam_unix.so nullok try_first_pass \nauth        \[default=die\] pam_faillock.so authfail audit deny=5 unlock_time=120/g' /etc/pam.d/system-auth
sudo sed -i 's/auth        required      pam_deny.so/auth        required      pam_faillock.so preauth silent audit deny=3 unlock_time=120 auth sufficient pam_unix.so nullok try_first_pass \nauth        \[default=die\] pam_faillock.so authfail audit deny=5 unlock_time=120/g' /etc/pam.d/password-auth

echo "Fix SRV-131"
sudo chgrp wheel /usr/bin/su
sudo chmod 4750 /usr/bin/su 

echo "Fix SRV-133"
sudo rm -rf /etc/cron.deny

echo "Fix SRV-159"
cat <<EOF | sudo tee -a /etc/profile >> /dev/null
export TIMEOUT=600
EOF

echo "Fix SRV-162"
echo "SULOG_FILE   /var/adm/sulog" | sudo tee -a /etc/login.defs > /dev/null
sudo touch /var/adm/sulog
sudo chmod 0640 /var/adm/sulog
sudo sed -i 's/auth\t\tsufficient\tpam_rootok.so/auth\t\tsufficient\tpam_rootok.so debug/g' /etc/pam.d/su

echo "Fix SRV-163"
cat << EOF | sudo tee /etc/issue /etc/issue.net /etc/motd >/dev/null
*****************************************
*                warning                *
*****************************************

This System is for authorized users only.

EOF
cat << EOT | sudo tee -a /etc/centrifydc/scripts/systemd/centrifydc.sh >/dev/null
cat << EOF | sudo tee /etc/issue >/dev/null
*****************************************
*                warning                *
*****************************************

This System is for authorized users only.

EOF
sudo systemctl restart sshd
EOT
cat << EOF | sudo tee /etc/update-motd.d/30-banner /usr/sbin/update-motd >/dev/null
EOF
sudo sed -i 's/^#Banner none/Banner \/etc\/issue/g' /etc/ssh/sshd_config
sudo sed -i 's/^#PrintMotd yes/PrintMotd no/g' /etc/ssh/sshd_config
sudo touch /var/lib/update-motd/disabled   
sudo rm -f /etc/cron.d/update-motd
sudo systemctl restart sshd.service

echo "Fix SRV-164"
for LIST in slocate screen stapusr stapsys stapdev; do 
  sudo /usr/sbin/groupdel $LIST 
done

echo "Fix SRV-168"
echo "*.alert                                                 /dev/console" | sudo tee -a /etc/rsyslog.conf > /dev/null
